local uv = require("luv")
local registry = require("agent.tool_registry")
local path_util = require("agent.util.path")
local shell_util = require("agent.util.shell")
local grep_tool = require("agent.tools.grep")

local parallel = {}

local SHELL_TOOLS = {
	ls = true,
	find = true,
	grep = true,
}

local FILE_MUTATION_TOOLS = {
	edit = true,
	multi_edit = true,
	write = true,
}

local FILE_READ_TOOLS = {
	read = true,
}

local JOB_CONTROL_TOOLS = {
	job_output = true,
	job_status = true,
	job_stop = true,
	job_wait = true,
}

local START_EVENT_TOOLS = {
	delegate_readonly = true,
	edit = true,
	multi_edit = true,
	find = true,
	grep = true,
	job_output = true,
	job_start = true,
	job_status = true,
	job_stop = true,
	job_wait = true,
	ls = true,
	run = true,
	shell = true,
	update_plan = true,
	write = true,
}

local DAG_TOOLS = { ls = true, read = true, find = true, grep = true, delegate_readonly = true }

local function is_readonly_fork_join_batch(tool_calls)
	local has_shell, has_delegate = false, false
	for _, tc in ipairs(tool_calls) do
		if not DAG_TOOLS[tc.name] then return false end
		if SHELL_TOOLS[tc.name] then has_shell = true end
		if tc.name == "delegate_readonly" then has_delegate = true end
	end
	return has_shell and has_delegate
end

local function event_call_id(tc, index)
	return tc.runtime_call_id or tc.native_call_id or (index and ("batch-" .. tostring(index)) or nil)
end

local function emit_start(on_tool, tc, index)
	if on_tool and START_EVENT_TOOLS[tc.name] then
		on_tool({ type = "tool", phase = "start", call_id = event_call_id(tc, index), model_index = index, name = tc.name, args = tc.args })
	end
end

local function execute_tool(tc, index, context, on_tool)
	if tc.name ~= "run" or not on_tool then
		return registry.execute(tc.name, tc.args, context)
	end
	local tool_context = setmetatable({
		progress = function(progress)
			on_tool({
				type = "tool",
				phase = "progress",
				call_id = event_call_id(tc, index),
				model_index = index,
				name = tc.name,
				args = tc.args,
				progress = progress,
			})
		end,
	}, { __index = context })
	return registry.execute(tc.name, tc.args, tool_context)
end

local function file_mutation_target(tc, context)
	if not FILE_MUTATION_TOOLS[tc.name] then
		return nil
	end
	local args = tc.args or {}
	if not args.path or args.path == "" then
		return nil
	end
	return path_util.resolve(args.path, context.cwd or ".")
end

local function file_read_target(tc, context)
	if not FILE_READ_TOOLS[tc.name] then
		return nil
	end
	local args = tc.args or {}
	if not args.path or args.path == "" then
		return nil
	end
	return path_util.resolve(args.path, context.cwd or ".")
end

local function stale_batch_result(path)
	return {
		is_error = true,
		content = "A previous tool call in this batch already modified " .. path .. ". Re-read the file before editing or writing it again.",
		summary = "stale batch mutation",
	}
end

local function dependent_batch_result(path)
	return {
		is_error = true,
		ui_state = "deferred",
		content = "This batch both reads and modifies " .. path .. ". Tool results from the same assistant message are not available to later tool calls; read the file first, then edit or write it in the next turn.",
		summary = "dependent batch mutation",
	}
end

local function edit_range(tc)
	if tc.name ~= "edit" then
		return nil
	end
	local args = tc.args or {}
	if not args.start_line or not args.start_tag or not args.end_tag then
		return nil
	end
	local start_line = math.floor(tonumber(args.start_line) or 0)
	local end_line = math.floor(tonumber(args.end_line) or start_line)
	if start_line < 1 or end_line < start_line then
		return nil
	end
	return start_line, end_line
end

local function safe_tagged_edit_group(items)
	for _, item in ipairs(items) do
		local start_line, end_line = edit_range(item.tc)
		if not start_line then
			return false
		end
		item.start_line = start_line
		item.end_line = end_line
	end

	table.sort(items, function(a, b)
		if a.start_line == b.start_line then
			return a.end_line > b.end_line
		end
		return a.start_line < b.start_line
	end)

	local previous_end = 0
	for _, item in ipairs(items) do
		if item.start_line <= previous_end then
			return false
		end
		previous_end = item.end_line
	end

	return true
end

local function collect_edit_groups(other_batch, context)
	local groups = {}
	for _, item in ipairs(other_batch) do
		local target = file_mutation_target(item.tc, context)
		if target and item.tc.name == "edit" then
			groups[target] = groups[target] or {}
			groups[target][#groups[target] + 1] = item
		end
	end

	local safe_groups = {}
	for target, items in pairs(groups) do
		if #items > 1 and safe_tagged_edit_group(items) then
			safe_groups[target] = items
		end
	end
	return safe_groups
end

local function collect_read_targets(other_batch, context)
	local targets = {}
	for _, item in ipairs(other_batch) do
		local target = file_read_target(item.tc, context)
		if target then
			targets[target] = true
		end
	end
	return targets
end

local function collect_write_targets(other_batch, context)
	local targets = {}
	for _, item in ipairs(other_batch) do
		if item.tc.name == "write" then
			local target = file_mutation_target(item.tc, context)
			if target then
				targets[target] = true
			end
		end
	end
	return targets
end

local function path_exists(path)
	local stat = uv.fs_stat(path)
	return stat ~= nil
end

local function tool_to_command(name, args, context)
	local cwd = context.cwd or "."

	if name == "ls" then
		local target = path_util.resolve(args.path or ".", cwd)
		return "ls -1 " .. shell_util.quote(target) .. " 2>/dev/null"
	elseif name == "find" then
		local target = path_util.resolve(args.path or ".", cwd)
		local max_depth = math.floor(tonumber(args.maxDepth) or 3)
		local pattern = args.pattern or ""
		local cmd = "find " .. shell_util.quote(target) .. " -maxdepth " .. tostring(max_depth) .. " -type f"
		if pattern ~= "" then
			cmd = cmd .. " -name " .. shell_util.quote(pattern)
		end
		return cmd .. " | sort"
	elseif name == "grep" then
		return grep_tool.command(args, context)
	end

	return nil
end

local MAX_BYTES = 20000
local MAX_READ_BATCH_BYTES = 24000

local function truncate(output)
	if #output <= MAX_BYTES then
		return output, false
	end
	return output:sub(1, MAX_BYTES) .. "\n[truncated at " .. MAX_BYTES .. " bytes]", true
end

local function count_lines(output)
	local count = 0
	for _ in output:gmatch("[^\n]+") do
		count = count + 1
	end
	return count
end

local function format_result(name, args, output, exit_code, context)
	if name == "grep" then
		return grep_tool.format_result(output, exit_code, context)
	end
	if exit_code == 127 then
		return {
			is_error = true,
			content = output ~= "" and output or "command not found",
			summary = "spawn failed",
		}
	end

	local truncated
	output, truncated = truncate(output)
	local count = count_lines(output)

	if name == "ls" then
		if exit_code ~= 0 then
			local target = args and args.path or "path"
			return {
				is_error = false,
				content = tostring(target) .. " does not exist",
				summary = "missing",
			}
		end
		return {
			is_error = false,
			content = output ~= "" and output or "(empty directory)",
			summary = tostring(count) .. " entries",
		}
	elseif name == "find" then
		local summary = tostring(count) .. " files"
		if truncated then summary = summary .. ", truncated" end
		return {
			is_error = false,
			content = output ~= "" and output or "(no files)",
			summary = summary,
		}
	end

	return { is_error = true, content = "unknown tool", summary = "error" }
end

local function normalized_number(value, fallback)
	local number = tonumber(value)
	if not number then
		number = fallback
	end
	return tostring(math.floor(number or 0))
end

local function read_call_key(tc, context)
	if tc.name ~= "read" then
		return nil
	end
	local args = tc.args or {}
	if not args.path or args.path == "" then
		return nil
	end
	local target = path_util.resolve(args.path, context.cwd or ".")
	return table.concat({
		target,
		normalized_number(args.offset, 1),
		normalized_number(args.limit, -1),
	}, "\0")
end

local function duplicate_read_result(original_index)
	return {
		is_error = false,
		content = "Duplicate read skipped; same result as tool call #" .. tostring(original_index) .. ".",
		summary = "duplicate read",
	}
end

local function already_read_result(info)
	local where = info and info.message_index and ("message #" .. tostring(info.message_index)) or "recent context"
	return {
		is_error = false,
		ui_state = "deferred",
		content = "Read skipped; this exact file range is already visible in " .. where .. ". Use the existing read result unless the file changed.",
		summary = "already in context",
	}
end

local function read_budget_result(max_bytes)
	return {
		is_error = false,
		ui_state = "deferred",
		content = "Read batch output budget reached (" .. tostring(max_bytes) .. " bytes). Use a smaller targeted read in the next turn.",
		summary = "read budget reached",
		harness_policy = {
			name = "shared_read_output_cap",
			strategy = "sequential_model_order_shared_budget",
			rationale = "bound total source returned by one model tool batch while exposing deferred reads",
			max_bytes = max_bytes,
		},
	}
end

local function missing_creation_read_result(path)
	return {
		is_error = false,
		ui_state = "deferred",
		content = path .. " does not exist yet; skipped same-batch read because this batch also creates it with write.",
		summary = "new file pending",
	}
end

local function skipped_run_after_failed_mutation_result()
	return {
		is_error = true,
		ui_state = "deferred",
		content = "Skipped run because an earlier edit/write in this batch failed. Re-read or fix the failed mutation before running verification.",
		summary = "skipped after failed mutation",
	}
end

local function pending_job_id_result()
	return {
		is_error = false,
		ui_state = "deferred",
		content = "Skipped same-batch job control because job_start creates the job id at execution time. Use the returned job_N id in the next turn.",
		summary = "job id pending",
	}
end

local function spawn_and_collect(cmd, callback)
	local stdout_pipe = uv.new_pipe()
	local stderr_pipe = uv.new_pipe()
	local chunks = {}
	local handle

	handle = uv.spawn("sh", {
		args = { "-c", cmd },
		stdio = { nil, stdout_pipe, stderr_pipe },
	}, function(code)
		stdout_pipe:close()
		stderr_pipe:close()
		handle:close()
		callback(table.concat(chunks), code)
	end)

	if not handle then
		stdout_pipe:close()
		stderr_pipe:close()
		callback("[error: failed to spawn process]", 127)
		return
	end

	stdout_pipe:read_start(function(err, data)
		if data then
			chunks[#chunks + 1] = data
		elseif not err then
			stdout_pipe:read_stop()
		end
	end)

	stderr_pipe:read_start(function(err, data)
		if data then
			chunks[#chunks + 1] = data
		elseif not err then
			stderr_pipe:read_stop()
		end
	end)
end

local function execute_flat_batch(tool_calls, context, on_tool)
	local automatic_fork_join = context.session
		and context.session.readonly_fork_join_enabled == true
		and is_readonly_fork_join_batch(tool_calls)
	if automatic_fork_join and on_tool then
		local original_on_tool = on_tool
		local leader_marked = false
		on_tool = function(event)
			event.readonly_fork_join = {
				active = true,
				leader = event.result ~= nil and not leader_marked,
			}
			if event.result ~= nil then leader_marked = true end
			original_on_tool(event)
		end
	end
	local shell_batch = {}
	local other_batch = {}
	local function is_cancelled()
		if type(context.cancelled) == "function" then
			return context.cancelled() == true
		end
		return false
	end

	for i, tc in ipairs(tool_calls) do
		if SHELL_TOOLS[tc.name] then
			local cmd = tool_to_command(tc.name, tc.args, context)
			if cmd then
				shell_batch[#shell_batch + 1] = { index = i, tc = tc, cmd = cmd }
			else
				other_batch[#other_batch + 1] = { index = i, tc = tc }
			end
		else
			other_batch[#other_batch + 1] = { index = i, tc = tc }
		end
	end

	local deduped_shell_batch = {}
	local shell_seen = {}
	for _, item in ipairs(shell_batch) do
		local key = item.tc.name .. "\0" .. item.cmd
		local existing = shell_seen[key]
		if existing then
			existing.duplicates = existing.duplicates or {}
			existing.duplicates[#existing.duplicates + 1] = item.index
		else
			shell_seen[key] = item
			deduped_shell_batch[#deduped_shell_batch + 1] = item
		end
	end
	shell_batch = deduped_shell_batch

	local results = {}
	local deduped_other_batch = {}
	local read_seen = {}
	local recent_read_keys = context.recent_read_keys or {}
	for _, item in ipairs(other_batch) do
		local key = read_call_key(item.tc, context)
		if key and read_seen[key] then
			results[item.index] = duplicate_read_result(read_seen[key])
		elseif key and recent_read_keys[key] then
			results[item.index] = already_read_result(recent_read_keys[key])
		else
			if key then
				read_seen[key] = item.index
			end
			deduped_other_batch[#deduped_other_batch + 1] = item
		end
	end
	other_batch = deduped_other_batch

	local write_targets = collect_write_targets(other_batch, context)
	local runnable_other_batch = {}
	for _, item in ipairs(other_batch) do
		local target = file_read_target(item.tc, context)
		if target and write_targets[target] and not path_exists(target) then
			results[item.index] = missing_creation_read_result(target)
		else
			runnable_other_batch[#runnable_other_batch + 1] = item
		end
	end
	other_batch = runnable_other_batch

	local pending_shell = 0
	local overlap_ready_nodes = context._dag_wave == true or automatic_fork_join
	if #shell_batch > 1 or (overlap_ready_nodes and #shell_batch == 1 and #other_batch > 0) then
		pending_shell = #shell_batch

		for _, item in ipairs(shell_batch) do
			emit_start(on_tool, item.tc, item.index)
			spawn_and_collect(item.cmd, function(output, exit_code)
				local result = format_result(item.tc.name, item.tc.args, output, exit_code, context)
				results[item.index] = result
				for _, duplicate_index in ipairs(item.duplicates or {}) do
					results[duplicate_index] = result
				end
				if on_tool then
					on_tool({ type = "tool", call_id = event_call_id(item.tc, item.index), model_index = item.index, name = item.tc.name, args = item.tc.args, result = result })
				end
				pending_shell = pending_shell - 1
			end)
		end
		if not overlap_ready_nodes then
			while pending_shell > 0 do
				uv.run("once")
				if is_cancelled() then break end
			end
		end
	elseif #shell_batch == 1 then
		local item = shell_batch[1]
		emit_start(on_tool, item.tc, item.index)
		local result = execute_tool(item.tc, item.index, context, on_tool)
		results[item.index] = result
		for _, duplicate_index in ipairs(item.duplicates or {}) do
			results[duplicate_index] = result
		end
		if on_tool then
			on_tool({ type = "tool", call_id = event_call_id(item.tc, item.index), model_index = item.index, name = item.tc.name, args = item.tc.args, result = result })
		end
	end

	local mutated_targets = {}
	local read_targets = collect_read_targets(other_batch, context)
	local edit_groups = collect_edit_groups(other_batch, context)
	local completed_group_targets = {}
	local read_batch_bytes = 0
	local max_read_batch_bytes = tonumber(context.session and context.session.read_batch_bytes)
		or MAX_READ_BATCH_BYTES
	max_read_batch_bytes = math.max(1000, math.floor(max_read_batch_bytes))
	local mutation_failed = false
	local pending_job_start = false
	for _, item in ipairs(other_batch) do
		-- Check cancellation between sequential tool executions
		if is_cancelled() then break end
		local tc = item.tc
		local mutation_target = file_mutation_target(tc, context)
		local result
		local result_emitted = false
		local edit_group = mutation_target and edit_groups[mutation_target]
		if tc.name == "run" and mutation_failed then
			result = skipped_run_after_failed_mutation_result()
		elseif JOB_CONTROL_TOOLS[tc.name] and pending_job_start then
			result = pending_job_id_result()
		elseif mutation_target and read_targets[mutation_target] then
			result = dependent_batch_result(mutation_target)
		elseif edit_group and not completed_group_targets[mutation_target] and not mutated_targets[mutation_target] then
			table.sort(edit_group, function(a, b)
				if a.start_line == b.start_line then
					return a.end_line > b.end_line
				end
				return a.start_line > b.start_line
			end)
			local any_success = false
			for _, group_item in ipairs(edit_group) do
				if is_cancelled() then break end
				emit_start(on_tool, group_item.tc, group_item.index)
				local group_result = execute_tool(group_item.tc, group_item.index, context, on_tool)
				if group_result then
					group_result.harness_policy = {
						name = "non_overlapping_same_file_edits",
						strategy = "descending_source_position",
						rationale = "preserve original tagged source coordinates when earlier edits change line counts",
						group_size = #edit_group,
						model_index = group_item.index,
					}
				end
				results[group_item.index] = group_result
				if group_result and not group_result.is_error then
					any_success = true
				elseif FILE_MUTATION_TOOLS[group_item.tc.name] then
					mutation_failed = true
				end
				if on_tool then
					on_tool({ type = "tool", call_id = event_call_id(group_item.tc, group_item.index), model_index = group_item.index, name = group_item.tc.name, args = group_item.tc.args, result = group_result })
				end
			end
			result_emitted = true
			completed_group_targets[mutation_target] = true
			if any_success then
				mutated_targets[mutation_target] = true
			end
			result = results[item.index]
		elseif edit_group and completed_group_targets[mutation_target] then
			result = results[item.index]
			result_emitted = true
		elseif mutation_target and mutated_targets[mutation_target] then
			result = stale_batch_result(mutation_target)
		elseif tc.name == "read" and read_batch_bytes >= max_read_batch_bytes then
			result = read_budget_result(max_read_batch_bytes)
		else
			emit_start(on_tool, tc, item.index)
			result = execute_tool(tc, item.index, context, on_tool)
			if mutation_target and result and not result.is_error then
				mutated_targets[mutation_target] = true
			end
		end
		if tc.name == "job_start" and result and not result.is_error then
			pending_job_start = true
		end
		if FILE_MUTATION_TOOLS[tc.name] and result and result.is_error then
			mutation_failed = true
		end
		if tc.name == "read" and result and not result.is_error and result.summary ~= "duplicate read" then
			read_batch_bytes = read_batch_bytes + #(result.content or "")
			if read_batch_bytes > max_read_batch_bytes then
				result = read_budget_result(max_read_batch_bytes)
			end
		end
		results[item.index] = result
		if on_tool and not result_emitted then
			on_tool({ type = "tool", call_id = event_call_id(tc, item.index), model_index = item.index, name = tc.name, args = tc.args, result = result })
		end
	end

	while pending_shell > 0 do
		uv.run("once")
		if is_cancelled() then break end
	end

	return results
end

local function dag_error(message)
	return { is_error = true, content = message, summary = "invalid tool DAG" }
end

local function clean_dag_args(args)
	local clean = {}
	for key, value in pairs(args or {}) do
		if key ~= "node_id" and key ~= "depends_on" then clean[key] = value end
	end
	return clean
end

local function execute_dag(tool_calls, context, on_tool)
	local nodes, by_id = {}, {}
	for index, tc in ipairs(tool_calls) do
		if not DAG_TOOLS[tc.name] then
			local results = {}
			for i = 1, #tool_calls do results[i] = dag_error("tool is not allowed in read-only DAG: " .. tostring(tc.name)) end
			return results
		end
		local args = tc.args or {}
		local node_id = args.node_id or ("auto_" .. tostring(index))
		local dependencies = args.depends_on or {}
		if type(node_id) ~= "string" or node_id == "" or not node_id:match("^[%w_-]+$") then
			local results = {}
			for i = 1, #tool_calls do results[i] = dag_error("invalid node_id at tool call #" .. tostring(index)) end
			return results
		end
		if by_id[node_id] then
			local results = {}
			for i = 1, #tool_calls do results[i] = dag_error("duplicate node_id: " .. node_id) end
			return results
		end
		if type(dependencies) ~= "table" or #dependencies > 10 then
			local results = {}
			for i = 1, #tool_calls do results[i] = dag_error("invalid depends_on for node: " .. node_id) end
			return results
		end
		local node = { id = node_id, dependencies = dependencies, index = index, tc = tc }
		nodes[#nodes + 1] = node
		by_id[node_id] = node
	end
	for _, node in ipairs(nodes) do
		for _, dependency in ipairs(node.dependencies) do
			if type(dependency) ~= "string" or not by_id[dependency] then
				local results = {}
				for i = 1, #tool_calls do results[i] = dag_error("unknown dependency for " .. node.id .. ": " .. tostring(dependency)) end
				return results
			end
		end
	end

	-- Validate acyclicity before executing any node, so malformed graphs have no partial effects.
	local indegree, dependents, queue = {}, {}, {}
	for _, node in ipairs(nodes) do
		indegree[node.id] = #node.dependencies
		if #node.dependencies == 0 then queue[#queue + 1] = node.id end
		for _, dependency in ipairs(node.dependencies) do
			dependents[dependency] = dependents[dependency] or {}
			dependents[dependency][#dependents[dependency] + 1] = node.id
		end
	end
	local visited, cursor = 0, 1
	while queue[cursor] do
		local node_id = queue[cursor]
		cursor = cursor + 1
		visited = visited + 1
		for _, dependent in ipairs(dependents[node_id] or {}) do
			indegree[dependent] = indegree[dependent] - 1
			if indegree[dependent] == 0 then queue[#queue + 1] = dependent end
		end
	end
	if visited ~= #nodes then
		local results = {}
		for i = 1, #tool_calls do results[i] = dag_error("tool DAG contains a cycle") end
		return results
	end

	local results, completed = {}, {}
	local remaining = #nodes
	local wave = 0
	while remaining > 0 do
		wave = wave + 1
		local ready = {}
		for _, node in ipairs(nodes) do
			if not completed[node.id] then
				local all_complete, failed_dependency = true, nil
				for _, dependency in ipairs(node.dependencies) do
					if not completed[dependency] then all_complete = false break end
					if results[by_id[dependency].index] and results[by_id[dependency].index].is_error then
						failed_dependency = dependency
					end
				end
				if all_complete then
					if failed_dependency then
						results[node.index] = {
							is_error = true,
							content = "dependency failed; node not executed: " .. failed_dependency,
							summary = "dependency failed",
							dag = { node_id = node.id, depends_on = node.dependencies, wave = wave, skipped = true },
						}
						completed[node.id] = true
						remaining = remaining - 1
						if on_tool then
							on_tool({ type = "tool", call_id = event_call_id(node.tc, node.index), model_index = node.index,
								name = node.tc.name, args = node.tc.args, result = results[node.index], dag = results[node.index].dag })
						end
					else
						ready[#ready + 1] = node
					end
				end
			end
		end
		if #ready > 0 then
			local calls = {}
			local call_nodes = {}
			for _, node in ipairs(ready) do
				local copy = {}
				for key, value in pairs(node.tc) do copy[key] = value end
				copy.args = clean_dag_args(node.tc.args)
				calls[#calls + 1] = copy
				call_nodes[#call_nodes + 1] = node
			end
			local wave_context = setmetatable({ _dag_wave = true }, { __index = context })
			local wave_results = execute_flat_batch(calls, wave_context, function(event)
				local node = call_nodes[event.model_index]
				if node then
					event.model_index = node.index
					event.args = node.tc.args
					event.dag = { node_id = node.id, depends_on = node.dependencies, wave = wave }
				end
				if on_tool then on_tool(event) end
			end)
			for ready_index, node in ipairs(ready) do
				local result = wave_results[ready_index]
				if result then result.dag = { node_id = node.id, depends_on = node.dependencies, wave = wave } end
				results[node.index] = result
				completed[node.id] = true
				remaining = remaining - 1
			end
		end
	end
	return results
end

function parallel.execute_batch(tool_calls, context, on_tool)
	context = context or {}
	if context.session and context.session.tool_dag_enabled == true then
		for _, tc in ipairs(tool_calls) do
			local args = tc.args or {}
			if args.node_id ~= nil or args.depends_on ~= nil then
				return execute_dag(tool_calls, context, on_tool)
			end
		end
	end
	return execute_flat_batch(tool_calls, context, on_tool)
end

parallel._execute_dag = execute_dag

return parallel
