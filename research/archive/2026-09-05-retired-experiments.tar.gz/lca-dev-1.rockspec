package = "lca"
version = "dev-1"
source = {
	url = "git+https://github.com/forkfork/lca.git",
	branch = "main",
}
description = {
	summary = "A Lua coding absurdity using OpenAI Codex OAuth credentials",
	detailed = [[
	lca is a from-scratch Lua coding absurdity with
	OpenAI Codex OAuth login, a terminal UI, local tools,
streaming responses, context compaction, and MCP server support.

The tag-based read/edit tool design is inspired by Salvatore Sanfilippo
(@antirez), especially https://antirez.com/news/166.
]],
	homepage = "https://github.com/forkfork/lca",
	license = "BSD-2-Clause",
}
dependencies = {
	"lua >= 5.5, < 5.6",
	"luasocket",
	"luasec",
	"lua-cjson",
	"luv",
	"lcatui",
}
build = {
	type = "builtin",
	modules = {
		["logo"] = "lua/logo.lua",
		["agent.commands"] = "lua/agent/commands.lua",
		["agent.compaction"] = "lua/agent/compaction.lua",
		["agent.config"] = "lua/agent/config.lua",
		["agent.codex_oauth"] = "lua/agent/codex_oauth.lua",
		["agent.core"] = "lua/agent/core.lua",
		["agent.experiment"] = "lua/agent/experiment.lua",
		["agent.experiment_worker"] = "lua/agent/experiment_worker.lua",
		["agent.jobs"] = "lua/agent/jobs.lua",
		["agent.job_supervisor"] = "lua/agent/job_supervisor.lua",
		["agent.lint"] = "lua/agent/lint.lua",
		["agent.login"] = "lua/agent/login.lua",
		["agent.mcp"] = "lua/agent/mcp.lua",
		["agent.net.http_transport"] = "lua/agent/net/http_transport.lua",
		["agent.net.websocket_transport"] = "lua/agent/net/websocket_transport.lua",
		["agent.parallel"] = "lua/agent/parallel.lua",
		["agent.project_context"] = "lua/agent/project_context.lua",
		["agent.project_index"] = "lua/agent/project_index.lua",
		["agent.runtime_inventory"] = "lua/agent/runtime_inventory.lua",
		["agent.session"] = "lua/agent/session.lua",
		["agent.self_research"] = "lua/agent/self_research.lua",
		["agent.system_prompt"] = "lua/agent/system_prompt.lua",
		["agent.tui"] = "lua/agent/tui.lua",
		["agent.tui_effects"] = "lua/agent/tui_effects.lua",
		["agent.tool_protocol"] = "lua/agent/tool_protocol.lua",
		["agent.tool_registry"] = "lua/agent/tool_registry.lua",
		["agent.providers"] = "lua/agent/providers/init.lua",
		["agent.providers.codex"] = "lua/agent/providers/codex.lua",
		["agent.tools.job_args"] = "lua/agent/tools/job_args.lua",
		["agent.tools.edit"] = "lua/agent/tools/edit.lua",
		["agent.tools.find"] = "lua/agent/tools/find.lua",
		["agent.tools.grep"] = "lua/agent/tools/grep.lua",
		["agent.tools.job_output"] = "lua/agent/tools/job_output.lua",
		["agent.tools.job_start"] = "lua/agent/tools/job_start.lua",
		["agent.tools.job_status"] = "lua/agent/tools/job_status.lua",
		["agent.tools.job_stop"] = "lua/agent/tools/job_stop.lua",
		["agent.tools.job_wait"] = "lua/agent/tools/job_wait.lua",
		["agent.tools.delegate_readonly"] = "lua/agent/tools/delegate_readonly.lua",
		["agent.tools.ls"] = "lua/agent/tools/ls.lua",
		["agent.tools.read"] = "lua/agent/tools/read.lua",
		["agent.tools.run"] = "lua/agent/tools/run.lua",
		["agent.tools.write"] = "lua/agent/tools/write.lua",
		["agent.util.fs"] = "lua/agent/util/fs.lua",
		["agent.util.json"] = "lua/agent/util/json.lua",
		["agent.util.path"] = "lua/agent/util/path.lua",
		["agent.util.shell"] = "lua/agent/util/shell.lua",
	},
	install = {
		bin = {
			["lca"] = "bin/lca",
			["lca-agent"] = "bin/agent.lua",
			["lca-repl"] = "bin/repl.lua",
			["lca-self-research"] = "bin/self-research.lua",
			["lca-experiment-runner"] = "bin/experiment-runner.lua",
			["lca-login"] = "scripts/login.lua",
			["lca-auth"] = "scripts/auth.lua",
		},
	},
}
