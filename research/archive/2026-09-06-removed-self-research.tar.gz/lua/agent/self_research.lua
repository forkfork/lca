local uv = require("luv")
local json = require("agent.util.json")

local self_research = {}

local MAX_LOG_BYTES = 60000
local MAX_TEXT_BYTES = 8000
local MAX_EVENT_CONTENT_BYTES = 2000
local MAX_EVENTS = 64
local MAX_SOURCE_BYTES = 200000
local MAX_SOURCE_EXCERPT_BYTES = 5000
local MAX_SOURCE_CONTEXT_BYTES = 16000
local MAX_RECURRENCE_BUNDLES = 500
local MAX_OCCURRENCES_PER_TURN = 8
local SCOUT_SAMPLE_PERCENT = 10
local SCOUT_RECENCY_DAYS = 120
local SCOUT_MAX_SEARCHES = 3
local MAX_SCOUT_MEMORY_ITEMS = 8
local MAX_SCOUT_MEMORY_BYTES = 64000
local SILENT_TOOL_THRESHOLD_MS = 10000
local SIGNIFICANT_SILENT_TOOL_MS = 30000

local function trim(value, limit)
	value = tostring(value or "")
	limit = tonumber(limit) or MAX_TEXT_BYTES
	if #value <= limit then return value end
	return value:sub(1, limit) .. "\n[truncated from " .. tostring(#value) .. " bytes]"
end

local function redact(value)
	value = tostring(value or "")
	value = value:gsub("([Aa]uthorization:%s*)[^\r\n]+", "%1[REDACTED]")
	value = value:gsub("([Bb]earer%s+)[%w%._%-]+", "%1[REDACTED]")
	for _, key in ipairs({ "accessToken", "access_token", "refreshToken", "refresh_token", "secretAccessKey", "secret_access_key", "apiKey", "api_key" }) do
		value = value:gsub('(\"' .. key .. '\"%s*:%s*\")[^\"]+', '%1[REDACTED]')
	end
	return value
end

local function mkdir_p(path)
	path = tostring(path or "")
	if path == "" then return nil, "empty directory path" end
	local prefix = path:sub(1, 1) == "/" and "/" or ""
	for part in path:gmatch("[^/]+") do
		prefix = prefix == "/" and (prefix .. part) or prefix == "" and part or (prefix .. "/" .. part)
		local ok, err = uv.fs_mkdir(prefix, tonumber("755", 8))
		if not ok and not tostring(err):find("EEXIST", 1, true) then return nil, err end
	end
	return true
end

local function write_file(path, value)
	local file, err = io.open(path, "w")
	if not file then return nil, err end
	file:write(value)
	file:close()
	return true
end

local function atomic_write(path, value)
	local tmp = path .. ".tmp-" .. tostring(uv.getpid())
	local ok, err = write_file(tmp, value)
	if not ok then return nil, err end
	local renamed, rename_err = uv.fs_rename(tmp, path)
	if not renamed then
		pcall(uv.fs_unlink, tmp)
		return nil, rename_err
	end
	return true
end

local function read_file(path)
	local file = io.open(path, "r")
	if not file then return nil end
	local value = file:read("*a")
	file:close()
	return value
end

local function append_file(path, value)
	local file, err = io.open(path, "a")
	if not file then return nil, err end
	file:write(value)
	file:close()
	return true
end

local function source_hash(value)
	local hash = 2166136261
	for index = 1, #value do
		hash = ((hash ~ value:byte(index)) * 16777619) & 0xffffffff
	end
	return string.format("fnv1a32:%08x", hash)
end

local function hash_number(value)
	local hash = 2166136261
	value = tostring(value or "")
	for index = 1, #value do
		hash = ((hash ~ value:byte(index)) * 16777619) & 0xffffffff
	end
	return hash
end

local function source_excerpt(value, patterns)
	local lines = {}
	for line in (value .. "\n"):gmatch("(.-)\n") do lines[#lines + 1] = line end
	local included = {}
	for _, pattern in ipairs(patterns or {}) do
		for line_number, line in ipairs(lines) do
			if line:find(pattern, 1, true) then
				for selected = math.max(1, line_number - 6), math.min(#lines, line_number + 34) do
					included[selected] = true
				end
			end
		end
	end
	local output, previous = {}, nil
	for line_number = 1, #lines do
		if included[line_number] then
			if previous and line_number > previous + 1 then output[#output + 1] = "..." end
			output[#output + 1] = string.format("%d: %s", line_number, lines[line_number])
			previous = line_number
		end
	end
	return trim(redact(table.concat(output, "\n")), MAX_SOURCE_EXCERPT_BYTES)
end

local function compact_args(args)
	args = type(args) == "table" and args or {}
	local result = {}
	for _, key in ipairs({ "path", "command", "pattern", "glob", "offset", "limit", "maxDepth", "start_line", "end_line" }) do
		if args[key] ~= nil then result[key] = trim(redact(args[key]), 500) end
	end
	return result
end

local function compact_events(events)
	events = type(events) == "table" and events or {}
	local result = {}
	local selected = {}
	if #events <= MAX_EVENTS then
		for index = 1, #events do selected[#selected + 1] = events[index] end
	else
		for index = 1, MAX_EVENTS / 2 do selected[#selected + 1] = events[index] end
		selected[#selected + 1] = { phase = "summary", name = "events_omitted", args = { limit = #events - MAX_EVENTS } }
		for index = #events - MAX_EVENTS / 2 + 1, #events do selected[#selected + 1] = events[index] end
	end
	for _, event in ipairs(selected) do
		local item = {
			phase = event.phase or "finish",
			name = tostring(event.name or "tool"),
			call_id = event.call_id and trim(redact(event.call_id), 160) or nil,
			model_call_id = tonumber(event.model_call_id),
			batch_id = tonumber(event.batch_id),
			model_index = tonumber(event.model_index),
			observed_at_ms = tonumber(event.observed_at_ms),
			duration_ms = tonumber(event.duration_ms),
			args = compact_args(event.args),
		}
		if type(event.progress) == "table" then
			item.progress = {
				elapsed_ms = tonumber(event.progress.elapsed_ms),
				output_bytes = tonumber(event.progress.output_bytes),
				output_chunks = tonumber(event.progress.output_chunks),
			}
		end
		if type(event.result) == "table" then
			item.result = {
				is_error = event.result.is_error == true,
				summary = trim(redact(event.result.summary), 500),
				content = trim(redact(event.result.content), MAX_EVENT_CONTENT_BYTES),
			}
			if type(event.result.harness_policy) == "table" then
				local policy = event.result.harness_policy
				item.result.harness_policy = {
					name = trim(redact(policy.name), 120),
					strategy = trim(redact(policy.strategy), 120),
					rationale = trim(redact(policy.rationale), 300),
					group_size = tonumber(policy.group_size),
					model_index = tonumber(policy.model_index),
					max_bytes = tonumber(policy.max_bytes),
				}
			end
		end
		result[#result + 1] = item
	end
	return result
end

local function is_read_budget_event(event)
	local result = type(event) == "table" and type(event.result) == "table" and event.result or nil
	if tostring(event and event.name or ""):lower() ~= "read" or not result then return false end
	if tostring(result.summary or ""):lower() == "read budget reached" then return true end
	local policy = type(result.harness_policy) == "table" and result.harness_policy or {}
	return tostring(policy.name or ""):lower() == "shared_read_output_cap"
end

local function authoritative_facts(events, options)
	events = type(events) == "table" and events or {}
	options = options or {}
	local facts = {
		version = 1,
		event_counts = { finish = 0, errors = 0 },
		admission = { significant_supported = false, reasons = {} },
	}
	local hits, batches, batch_order = {}, {}, {}
	local progress_by_call = {}
	local function call_key(event)
		return tostring(event.call_id or table.concat({ event.name or "tool", event.model_call_id or event.batch_id or 0, event.model_index or 0 }, ":"))
	end
	for _, event in ipairs(events) do
		if event.phase == "progress" then
			local key = call_key(event)
			progress_by_call[key] = (progress_by_call[key] or 0) + 1
		end
	end
	local silent_tools = {}
	for index, event in ipairs(events) do
		local phase = event.phase or "finish"
		if phase == "finish" then
			facts.event_counts.finish = facts.event_counts.finish + 1
			if event.result and event.result.is_error == true then
				facts.event_counts.errors = facts.event_counts.errors + 1
			end
		end
		if is_read_budget_event(event) then
			hits[#hits + 1] = { index = index, event = event }
			local batch_id = tonumber(event.batch_id or event.model_call_id) or 0
			if not batches[batch_id] then
				batches[batch_id] = 0
				batch_order[#batch_order + 1] = batch_id
			end
			batches[batch_id] = batches[batch_id] + 1
		end
		local duration_ms = tonumber(event.duration_ms) or 0
		if phase == "finish" and tostring(event.name or ""):lower() == "run"
			and duration_ms >= SILENT_TOOL_THRESHOLD_MS and (progress_by_call[call_key(event)] or 0) == 0 then
			silent_tools[#silent_tools + 1] = {
				event_index = index,
				call_id = event.call_id,
				duration_ms = duration_ms,
				progress_events = 0,
				summary = trim(redact(event.result and event.result.summary), 160),
			}
		end
	end
	if #silent_tools > 0 then
		local max_duration_ms = 0
		for _, item in ipairs(silent_tools) do max_duration_ms = math.max(max_duration_ms, item.duration_ms) end
		facts.runtime_observability = {
			id = "silent_long_running_tool",
			threshold_ms = SILENT_TOOL_THRESHOLD_MS,
			silent_tools = silent_tools,
			count = #silent_tools,
			max_duration_ms = max_duration_ms,
			statement = string.format("%d run tool(s) lasted at least %.0fs without a progress event; the longest lasted %.1fs.",
				#silent_tools, SILENT_TOOL_THRESHOLD_MS / 1000, max_duration_ms / 1000),
		}
	end
	if #hits > 0 then
		local by_batch = {}
		for _, batch_id in ipairs(batch_order) do
			by_batch[#by_batch + 1] = { batch_id = batch_id, hits = batches[batch_id] }
		end
		local recovered = 0
		for _, hit in ipairs(hits) do
			local path = tostring(hit.event.args and hit.event.args.path or "")
			for later = hit.index + 1, #events do
				local candidate = events[later]
				if tostring(candidate.name or ""):lower() == "read" and not is_read_budget_event(candidate)
					and candidate.result and candidate.result.is_error ~= true
					and tostring(candidate.args and candidate.args.path or "") == path then
					recovered = recovered + 1
					break
				end
			end
		end
		local policy = hits[1].event.result and hits[1].event.result.harness_policy or {}
		facts.read_output_cap = {
			id = "read_output_cap",
			hits = #hits,
			hits_by_batch = by_batch,
			same_path_recovery_hits = recovered,
			strategy = tostring(policy.strategy or "unknown"),
			max_bytes = tonumber(policy.max_bytes),
			extra_model_calls_proven = false,
			statement = string.format("%d read results were deferred by the shared batch cap; %d were followed by a successful read of the same path; extra model calls are not proven.", #hits, recovered),
		}
	end
	local meta = type(options.response_meta) == "table" and options.response_meta or {}
	local status = tonumber(meta.status or meta.status_code or meta._http_status) or 0
	local transcript = tostring(options.transcript or ""):lower()
	local function admit(reason)
		facts.admission.significant_supported = true
		facts.admission.reasons[#facts.admission.reasons + 1] = reason
	end
	if options.outcome == "error" then admit("turn_outcome_error") end
	if status >= 400 then admit("provider_http_failure") end
	if transcript:find("no tool call found for function call output with call_id", 1, true) then
		facts.native_tool_pairing = {
			id = "orphan_function_call_output",
			pair_closure_required = true,
			context_slimming_observed = transcript:find("[context] slim audit", 1, true) ~= nil,
			statement = "The provider rejected a function_call_output whose matching function_call was absent from the submitted history.",
		}
		admit("orphan_function_call_output")
	end
	if transcript:find("tool budget exhausted", 1, true) then admit("tool_budget_exhausted") end
	if transcript:find("context hard limit stopped", 1, true) then admit("context_hard_limit_stop") end
	if facts.runtime_observability and facts.runtime_observability.max_duration_ms >= SIGNIFICANT_SILENT_TOOL_MS then
		admit("long_running_tool_without_progress")
	end
	return facts
end

local SOURCE_ROUTES = {
	mutations = {
		invariants = {
			"Non-overlapping tagged edits to one file may run bottom-up to preserve original source coordinates.",
			"Overlapping, ambiguous, or stale tagged edits must fail instead of guessing.",
		},
		modules = {
			{ name = "agent.parallel", patterns = { "safe_tagged_edit_group", "collect_edit_groups", "descending_source_position", "stale_batch_result" } },
			{ name = "agent.tools.edit", patterns = { "tagged_range", "relocated_candidates", "execute_tagged", "execute_multi" } },
		},
	},
	protocol = {
		invariants = {
			"Only validated tool calls should execute; malformed or simulated calls remain assistant text.",
		},
		modules = {
			{ name = "agent.tool_protocol", patterns = { "extract_all_tool_calls", "validate_tool_calls", "strip_tool_calls", "tool_result_message" } },
			{ name = "agent.core", patterns = { "TOOL PROTOCOL VIOLATION", "FALSE TOOL" } },
		},
	},
	context = {
		invariants = { "Compaction must preserve the active task and tool-result causality." },
		modules = {
			{ name = "agent.core", patterns = { "prepare_model_context", "intra%-turn" } },
			{ name = "agent.compaction", patterns = { "compact", "summary" } },
		},
	},
	transport = {
		invariants = { "Fallbacks and retries must remain bounded and expose their final transport outcome." },
		modules = {
			{ name = "agent.providers.codex", patterns = { "websocket", "fallback", "max_retries" } },
			{ name = "agent.net.websocket_transport", patterns = { "normalize_deadlines", "request_deadline" } },
		},
	},
	jobs = {
		invariants = { "Background jobs must report failure and release their process resources." },
		modules = {
			{ name = "agent.jobs", patterns = { "cancel", "error", "close" } },
			{ name = "agent.job_supervisor", patterns = { "cancel", "error", "close" } },
		},
	},
	reads = {
		invariants = {
			"The read-output cap is a shared per-model-batch byte budget applied sequentially in model order.",
			"A cap-deferred read is intentional context control, not a tool failure; downstream cost must be measured rather than inferred.",
		},
		modules = {
			{ name = "agent.parallel", patterns = { "MAX_READ_BATCH_BYTES", "read_budget_result", "read_batch_bytes" } },
		},
	},
	observability = {
		invariants = {
			"Long-running foreground tools must emit bounded progress heartbeats so the TUI can show elapsed work without inventing completion percentage.",
			"Research packets must preserve measured duration and progress-event counts for runtime observability claims.",
		},
		modules = {
			{ name = "agent.tools.run", patterns = { "progress_timer", "output_bytes", "progress_interval_ms" } },
			{ name = "agent.core", patterns = { "observed_at_ms", "duration_ms", "TOOL PROGRESS" } },
			{ name = "agent.tui", patterns = { "event.phase == \"progress\"", "still running", "results arriving" } },
		},
	},
}

local function source_route_names(options)
	local selected = {}
	local function add(name) selected[name] = true end
	local progress_by_call = {}
	local function call_key(event)
		return tostring(event.call_id or table.concat({ event.name or "tool", event.model_call_id or event.batch_id or 0, event.model_index or 0 }, ":"))
	end
	for _, event in ipairs(type(options.events) == "table" and options.events or {}) do
		if event.phase == "progress" then progress_by_call[call_key(event)] = true end
	end
	for _, event in ipairs(type(options.events) == "table" and options.events or {}) do
		local name = tostring(event.name or ""):lower()
		local result = type(event.result) == "table" and event.result or nil
		if result and type(result.harness_policy) == "table"
			and (name == "edit" or name == "multi_edit" or name == "write") then add("mutations") end
		if name == "read" and result and (tostring(result.summary or ""):lower() == "read budget reached"
			or (type(result.harness_policy) == "table" and result.harness_policy.name == "shared_read_output_cap")) then add("reads") end
		if name == "multi_edit" then add("mutations") end
		if result and (name == "edit" or name == "write") then
			local evidence = (tostring(result.summary or "") .. " " .. tostring(result.content or "")):lower()
			if evidence:find("stale", 1, true) or evidence:find("overlap", 1, true)
				or evidence:find("ambiguous", 1, true) then add("mutations") end
		end
		if tostring(event.phase or ""):lower() == "error" and name:find("job", 1, true) then add("jobs") end
		if result and result.is_error == true and name:find("job", 1, true) then add("jobs") end
		if name == "run" and (event.phase or "finish") == "finish"
			and (tonumber(event.duration_ms) or 0) >= SILENT_TOOL_THRESHOLD_MS
			and not progress_by_call[call_key(event)] then add("observability") end
	end
	local transcript = tostring(options.transcript or ""):lower()
	if transcript:find("tool protocol violation", 1, true)
		or transcript:find("false tool", 1, true)
		or transcript:find("tool parse error", 1, true) then add("protocol") end
	if (tonumber(options.context_compactions) or 0) > 0 then add("context") end
	local meta = type(options.response_meta) == "table" and options.response_meta or {}
	if meta.transport_fallback or (tonumber(meta.status or meta.status_code) or 0) >= 400 then add("transport") end
	local names = {}
	for _, name in ipairs({ "mutations", "protocol", "context", "transport", "jobs", "reads", "observability" }) do
		if selected[name] then names[#names + 1] = name end
	end
	return names
end

function self_research.source_context(options)
	options = options or {}
	local routes = source_route_names(options)
	if #routes == 0 then return nil end
	local context = { routes = routes, invariants = {}, sources = {} }
	local modules, seen_modules = {}, {}
	for _, route_name in ipairs(routes) do
		local route = SOURCE_ROUTES[route_name]
		for _, invariant in ipairs(route.invariants) do context.invariants[#context.invariants + 1] = invariant end
		for _, module in ipairs(route.modules) do
			if not seen_modules[module.name] then
				seen_modules[module.name] = true
				modules[#modules + 1] = module
			end
		end
	end
	for _, module in ipairs(modules) do
		local path = options.source_resolver and options.source_resolver(module.name)
			or package.searchpath(module.name, package.path)
		local source = path and (options.source_loader and options.source_loader(path) or read_file(path))
		if source and #source <= MAX_SOURCE_BYTES then
			local item = {
				module = module.name,
				path = path,
				hash = source_hash(source),
				patterns = module.patterns,
				excerpt = source_excerpt(source, module.patterns),
			}
			if item.excerpt ~= "" then
				context.sources[#context.sources + 1] = item
				if #json.encode(context) > MAX_SOURCE_CONTEXT_BYTES then
					context.sources[#context.sources] = nil
					break
				end
			end
		end
	end
	return context
end

function self_research.default_inbox(home)
	home = tostring(home or os.getenv("HOME") or ".")
	return home .. "/.lca/research/inbox"
end

function self_research.resolve_inbox(cwd, configured, explicitly_enabled)
	if os.getenv("LCA_SELF_RESEARCH") == "0" and not explicitly_enabled then return nil end
	configured = configured or os.getenv("LCA_SELF_RESEARCH_DIR")
	if configured and configured ~= "" then return configured end
	return self_research.default_inbox()
end

function self_research.log_position(path)
	local stat = path and uv.fs_stat(path)
	return stat and tonumber(stat.size) or 0
end

function self_research.log_slice(path, first, last)
	if not path then return "" end
	local file = io.open(path, "r")
	if not file then return "" end
	first = math.max(0, tonumber(first) or 0)
	last = math.max(first, tonumber(last) or self_research.log_position(path))
	if last - first > MAX_LOG_BYTES then first = last - MAX_LOG_BYTES end
	file:seek("set", first)
	local value = file:read(last - first) or ""
	file:close()
	return trim(redact(value), MAX_LOG_BYTES)
end

function self_research.build_packet(options)
	options = options or {}
	local raw_events = type(options.events) == "table" and options.events or {}
	local events = compact_events(raw_events)
	return {
		version = 3,
		created_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
		session_id = tostring(options.session_id or "unknown"),
		turn = tonumber(options.turn) or 0,
		cwd = tostring(options.cwd or "."),
		model = tostring(options.model or ""),
		reasoning_effort = options.reasoning_effort,
		service_tier = options.service_tier,
		credentials_path = options.credentials_path,
		prompt = trim(redact(options.prompt), MAX_TEXT_BYTES),
		assistant = trim(redact(options.assistant), MAX_TEXT_BYTES),
		outcome = options.outcome or "complete",
		usage = type(options.usage) == "table" and options.usage or nil,
		response_meta = type(options.response_meta) == "table" and options.response_meta or nil,
		context_compactions = tonumber(options.context_compactions) or 0,
		events = events,
		authoritative_facts = authoritative_facts(raw_events, options),
		transcript = trim(redact(options.transcript), MAX_LOG_BYTES),
		harness_context = self_research.source_context(options),
	}
end

local SCOUT_TOPICS = {
	mutations = { "stale edit recovery coding agent", "transactional agent code edits" },
	protocol = { "tool schema repair agent eval", "coding agent tool protocol failure" },
	context = { "coding agent context reset compaction handoff", "tool output context budget agent" },
	transport = { "agent tool cancellation process cleanup", "streaming agent transport recovery" },
	jobs = { "coding agent background process supervision cancellation" },
	reads = { "coding agent read output truncation context benchmark" },
	observability = { "terminal coding agent long running command progress heartbeat", "CLI progress indicators unknown duration UX" },
}

local function scout_recency_after(now)
	return os.date("!%Y-%m-%d", (tonumber(now) or os.time()) - SCOUT_RECENCY_DAYS * 24 * 60 * 60)
end

function self_research.scout_policy(packet, options)
	packet = type(packet) == "table" and packet or {}
	options = options or {}
	local routes = type(packet.harness_context) == "table" and packet.harness_context.routes or {}
	local topics, seen = {}, {}
	for _, route in ipairs(type(routes) == "table" and routes or {}) do
		for _, topic in ipairs(SCOUT_TOPICS[tostring(route)] or {}) do
			if not seen[topic] then seen[topic] = true; topics[#topics + 1] = topic end
		end
	end
	local reason
	local facts = type(packet.authoritative_facts) == "table" and packet.authoritative_facts or {}
	if type(facts.admission) == "table" and facts.admission.significant_supported == true then
		reason = "observed harness failure"
	end
	if type(facts.runtime_observability) == "table" and (tonumber(facts.runtime_observability.count) or 0) > 0 then
		reason = "observed runtime observability gap"
	end
	for _, recurrence in ipairs(type(packet.recurrence_context) == "table" and packet.recurrence_context or {}) do
		local outcomes = type(recurrence.outcomes) == "table" and recurrence.outcomes or {}
		if (tonumber(recurrence.independent_sessions) or 0) >= 2
			and ((tonumber(outcomes.adverse) or 0) > 0 or (tonumber(outcomes.recovered) or 0) >= 2) then
			reason = reason or "recurring harness friction"
		end
	end
	if not reason and #topics > 0 then
		local sample = tonumber(options.sample_percent) or SCOUT_SAMPLE_PERCENT
		local roll = hash_number(tostring(packet.session_id or "unknown") .. ":" .. tostring(packet.turn or 0)) % 100
		if roll < math.max(0, math.min(100, sample)) then reason = "bounded curiosity sample" end
	end
	return {
		version = 1,
		enabled = reason ~= nil,
		reason = reason,
		recency_after = scout_recency_after(options.now),
		max_searches = SCOUT_MAX_SEARCHES,
		topics = topics,
	}
end

function self_research.recent_external_scouts(inbox)
	local research_root = tostring(inbox or ""):match("^(.*)/[^/]+$")
	if not research_root then return nil end
	local file = io.open(research_root .. "/external-scouts.jsonl", "r")
	if not file then return nil end
	local size = file:seek("end") or 0
	local first = math.max(0, size - MAX_SCOUT_MEMORY_BYTES)
	file:seek("set", first)
	if first > 0 then file:read("*l") end
	local lines = {}
	for line in file:lines() do lines[#lines + 1] = line end
	file:close()
	local result = {}
	for index = #lines, 1, -1 do
		local decoded
		pcall(function() decoded = json.decode(lines[index]) end)
		if type(decoded) == "table" and decoded.technique and decoded.technique ~= "" then
			local sources = {}
			for _, source in ipairs(type(decoded.sources) == "table" and decoded.sources or {}) do
				if #sources >= 4 then break end
				sources[#sources + 1] = trim(redact(source), 500)
			end
			result[#result + 1] = {
				created_at = trim(decoded.created_at, 40),
				reason = trim(redact(decoded.reason), 120),
				technique = trim(redact(decoded.technique), 300),
				sources = sources,
			}
			if #result >= MAX_SCOUT_MEMORY_ITEMS then break end
		end
	end
	return #result > 0 and result or nil
end

local function slug(value, fallback)
	value = tostring(value or ""):lower():gsub("[^%w]+", "_"):gsub("^_+", ""):gsub("_+$", "")
	return value ~= "" and value or fallback or "unknown"
end

local function verification_succeeded(events, after_index)
	for index = (tonumber(after_index) or 0) + 1, #events do
		local event = events[index]
		local command = type(event.args) == "table" and tostring(event.args.command or ""):lower() or ""
		local result = type(event.result) == "table" and event.result or nil
		if tostring(event.name or ""):lower() == "run" and result and result.is_error ~= true
			and (command:find("test", 1, true) or command:find("check", 1, true)
				or command:find("lint", 1, true) or command:find("spec", 1, true)) then
			return true
		end
	end
	return false
end

local function harness_hash(packet, route)
	local context = type(packet.harness_context) == "table" and packet.harness_context or {}
	local route_present = false
	for _, name in ipairs(type(context.routes) == "table" and context.routes or {}) do
		if name == route then route_present = true; break end
	end
	if not route_present then return nil end
	local hashes = {}
	for _, source in ipairs(type(context.sources) == "table" and context.sources or {}) do
		if source.hash then hashes[#hashes + 1] = tostring(source.hash) end
	end
	return #hashes > 0 and table.concat(hashes, "+") or nil
end

function self_research.classify_occurrences(packet)
	packet = type(packet) == "table" and packet or {}
	local events = type(packet.events) == "table" and packet.events or {}
	local occurrences, seen = {}, {}
	local function add(subsystem, event, mechanism, outcome, evidence, event_index)
		if #occurrences >= MAX_OCCURRENCES_PER_TURN then return end
		local fingerprint = table.concat({ slug(subsystem), slug(event), slug(mechanism) }, ".")
		if seen[fingerprint] then return end
		seen[fingerprint] = true
		occurrences[#occurrences + 1] = {
			fingerprint = fingerprint,
			subsystem = subsystem,
			event = event,
			mechanism = mechanism,
			outcome = outcome or "unknown",
			evidence = trim(redact(evidence), 240):gsub("[\r\n]+", " "),
			session_id = tostring(packet.session_id or "unknown"),
			turn = tonumber(packet.turn) or 0,
			created_at = packet.created_at,
			harness_hash = harness_hash(packet, subsystem),
			event_index = tonumber(event_index),
		}
	end

	local policies = {}
	local stale = {}
	for index, item in ipairs(events) do
		local name = tostring(item.name or ""):lower()
		local result = type(item.result) == "table" and item.result or nil
		local path = type(item.args) == "table" and tostring(item.args.path or "") or ""
		if result and (name == "edit" or name == "write" or name == "multi_edit") then
			if type(result.harness_policy) == "table" then
				local policy = result.harness_policy
				local mechanism = policy.strategy or policy.name or "declared_policy"
				local key = slug(mechanism)
				local previous = policies[key]
				policies[key] = {
					mechanism = mechanism,
					index = index,
					error = result.is_error == true or (previous and previous.error == true) or false,
				}
			end
			local detail = (tostring(result.summary or "") .. " " .. tostring(result.content or "")):lower()
			if detail:find("stale", 1, true) or detail:find("ambiguous", 1, true) or detail:find("overlap", 1, true) then
				stale[path ~= "" and path or "unknown"] = { index = index, error = result.is_error == true, detail = detail }
			end
		end
	end
	for _, policy in pairs(policies) do
		local outcome = policy.error and "adverse" or verification_succeeded(events, policy.index) and "verified" or "harmless"
		add("mutations", "same_file_group", policy.mechanism, outcome,
			"Declared same-file mutation policy " .. tostring(policy.mechanism), policy.index)
	end
	for path, signal in pairs(stale) do
		local recovered = false
		for index = signal.index + 1, #events do
			local item = events[index]
			local result = type(item.result) == "table" and item.result or nil
			if result and result.is_error ~= true and type(item.args) == "table" and tostring(item.args.path or "") == path then
				recovered = true; break
			end
		end
		add("mutations", "stale_or_ambiguous_edit", "guard", recovered and "recovered" or signal.error and "adverse" or "contained",
			"Mutation guard evidence for " .. path, signal.index)
	end

	local transcript = tostring(packet.transcript or ""):lower()
	if transcript:find("tool protocol violation", 1, true) or transcript:find("false tool", 1, true)
		or transcript:find("tool parse error", 1, true) then
		add("protocol", "invalid_tool_text", "guard", packet.outcome == "error" and "adverse" or "contained",
			"Transcript contains a tool protocol guard marker")
	end
	local meta = type(packet.response_meta) == "table" and packet.response_meta or {}
	if meta.transport_fallback then
		add("transport", "fallback", meta.transport or meta.fallback_transport or "provider_fallback",
			packet.outcome == "complete" and "recovered" or "adverse", "Response metadata records a transport fallback")
	end
	local status_code = tonumber(meta.status or meta.status_code) or 0
	if status_code >= 400 then
		add("transport", "request_failure", "http_" .. tostring(status_code), "adverse",
			"Response metadata records HTTP status " .. tostring(status_code))
	end
	if (tonumber(packet.context_compactions) or 0) > 0 then
		add("context", "compaction", "automatic", packet.outcome == "complete" and "preserved" or "adverse",
			tostring(packet.context_compactions) .. " context compaction(s)")
	end
	local runtime = type(packet.authoritative_facts) == "table"
		and type(packet.authoritative_facts.runtime_observability) == "table"
		and packet.authoritative_facts.runtime_observability or nil
	if runtime then
		for _, item in ipairs(type(runtime.silent_tools) == "table" and runtime.silent_tools or {}) do
			add("observability", "silent_long_tool", "foreground_run_without_progress", "adverse",
				string.format("run emitted no progress event for %.1fs", (tonumber(item.duration_ms) or 0) / 1000), item.event_index)
		end
	end
	for index, item in ipairs(events) do
		local name = tostring(item.name or ""):lower()
		local result = type(item.result) == "table" and item.result or nil
		if result and result.is_error == true and name:find("job", 1, true) then
			add("jobs", "job_failure", name, "adverse", tostring(result.summary or name .. " failed"), index)
		end
	end
	table.sort(occurrences, function(left, right) return left.fingerprint < right.fingerprint end)
	return occurrences
end

local function recurrence_record(occurrences)
	return {
		version = 1,
		created_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
		occurrences = occurrences,
	}
end

local function scan_occurrence_records(inbox)
	local scanner = uv.fs_scandir(inbox)
	if not scanner then return {} end
	local names = {}
	while true do
		local name, kind = uv.fs_scandir_next(scanner)
		if not name then break end
		if kind == "directory" then names[#names + 1] = name end
	end
	table.sort(names, function(left, right) return left > right end)
	local records = {}
	for index = 1, math.min(#names, MAX_RECURRENCE_BUNDLES) do
		local body = read_file(inbox .. "/" .. names[index] .. "/occurrence.json")
		if body then
			local decoded
			pcall(function() decoded = json.decode(body) end)
			if type(decoded) == "table" then records[#records + 1] = decoded end
		end
	end
	return records
end

function self_research.recurrence_for(inbox, current)
	current = type(current) == "table" and current or {}
	local wanted = {}
	for _, occurrence in ipairs(current) do wanted[occurrence.fingerprint] = true end
	if next(wanted) == nil then return {} end
	local aggregates = {}
	for _, record in ipairs(scan_occurrence_records(inbox)) do
		for _, occurrence in ipairs(type(record.occurrences) == "table" and record.occurrences or {}) do
			local fingerprint = tostring(occurrence.fingerprint or "")
			if wanted[fingerprint] then
				local aggregate = aggregates[fingerprint] or {
					fingerprint = fingerprint, total = 0, sessions = {}, outcomes = {}, harness_hashes = {},
					first_seen = nil, last_seen = nil,
				}
				aggregates[fingerprint] = aggregate
				aggregate.total = aggregate.total + 1
				aggregate.sessions[tostring(occurrence.session_id or "unknown")] = true
				local outcome = tostring(occurrence.outcome or "unknown")
				aggregate.outcomes[outcome] = (aggregate.outcomes[outcome] or 0) + 1
				if occurrence.harness_hash then aggregate.harness_hashes[tostring(occurrence.harness_hash)] = true end
				local seen_at = tostring(occurrence.created_at or record.created_at or "")
				if seen_at ~= "" and (not aggregate.first_seen or seen_at < aggregate.first_seen) then aggregate.first_seen = seen_at end
				if seen_at ~= "" and (not aggregate.last_seen or seen_at > aggregate.last_seen) then aggregate.last_seen = seen_at end
			end
		end
	end
	local result = {}
	for _, occurrence in ipairs(current) do
		local aggregate = aggregates[occurrence.fingerprint]
		if aggregate then
			aggregate.independent_sessions = 0
			for _ in pairs(aggregate.sessions) do aggregate.independent_sessions = aggregate.independent_sessions + 1 end
			aggregate.harness_versions = 0
			for _ in pairs(aggregate.harness_hashes) do aggregate.harness_versions = aggregate.harness_versions + 1 end
			aggregate.sessions = nil
			aggregate.harness_hashes = nil
			result[#result + 1] = aggregate
		end
	end
	return result
end

function self_research.format_recurrence(recurrence)
	if type(recurrence) ~= "table" or #recurrence == 0 then return "" end
	local lines = { "## Recurrence evidence", "Recurrence is descriptive only; it does not promote this observation." }
	local outcome_order = { "adverse", "recovered", "verified", "contained", "preserved", "harmless", "unknown" }
	for _, item in ipairs(recurrence) do
		local outcomes = {}
		for _, name in ipairs(outcome_order) do
			if item.outcomes and item.outcomes[name] then outcomes[#outcomes + 1] = name .. " " .. tostring(item.outcomes[name]) end
		end
		local occurrence_word = item.total == 1 and "occurrence" or "occurrences"
		local session_word = item.independent_sessions == 1 and "session" or "sessions"
		lines[#lines + 1] = string.format("- `%s` — %d %s across %d %s%s", item.fingerprint,
			item.total or 0, occurrence_word, item.independent_sessions or 0, session_word,
			#outcomes > 0 and "; " .. table.concat(outcomes, ", ") or "")
	end
	return table.concat(lines, "\n")
end

local ANALYSIS_SYSTEM_PROMPT = [[
You review one completed LCA coding-agent turn for evidence about the LCA harness itself.
You are not continuing the user's task, reviewing their application code, or proposing code changes.

Identify at most one concrete harness observation supported by the supplied event data or transcript. Good subjects include tool protocol failures, duplicated or wasteful work, stale-edit recovery, cancellation, misleading completion or verification state, context handling, transport behavior, and UI/runtime observability.

Do not treat an ordinary coding mistake, a project-specific design choice, or a failed test by itself as a harness flaw. Do not infer facts that are absent from the packet. Prefer no observation over a generic suggestion.

If there is no decision-useful harness evidence, output exactly:
NO_HARNESS_OBSERVATION

Otherwise begin with exactly these four metadata lines:
SIGNIFICANCE: significant or candidate
IMPACT: observed or potential
CONFIDENCE: high, medium, or low
SUMMARY: a concrete summary of at most 80 characters
You may add a fifth metadata line immediately after SUMMARY:
SCOUT_TECHNIQUE: a concise externally sourced technique, or none

Then output concise Markdown beginning with "# Harness observation" and include these sections:
## Evidence
## Harness hypothesis
## Proposed experiment
## Confidence

Evidence must cite exact event names, summaries, counts, or transcript phrases from the packet. A proposed experiment must be falsifiable. Never claim that a harness change should be made from one run.
The packet's authoritative_facts are computed by the harness. Treat their counts, batch identities, policies, and admission flags as ground truth. Never recount or contradict them. Do not claim that a mechanism forced an extra model call when extra_model_calls_proven is false.

Admission rules:
- Significant means the packet directly shows an adverse harness impact and confidence is high. Examples are a harness-caused incorrect result, failed or skipped operation, misleading success state, leaked process, repeated measurable waste, or protocol/transport failure.
- Potential risk, surprising ordering, hypothetical correctness impact, medium confidence, or a proposed experiment without observed harm is only a candidate. Successful downstream verification is evidence against a correctness-impact claim, though it does not prove absence of all risk.
- A result.harness_policy object is runtime provenance for an intentional harness decision. Account for its strategy and rationale before calling the behavior anomalous. Execution-event order need not equal model-emission order when a declared policy explains it.
- Tool start events are optional progress signals emitted only for tools expected to be slow; a successful fast tool such as read may intentionally have only a finish event. Successful non-mutating tool results may also be omitted from the text transcript while remaining authoritative in structured events. Do not report either omission as a lifecycle defect.
- harness_context is a bounded, signal-routed view of the installed harness implementation. Its paths and hashes identify the exact code examined; its invariants state intended behavior. Use excerpts to test a hypothesis, not as evidence that an issue occurred.
- recurrence_context is deterministic history for the current structured fingerprints. It includes harmless and successful counter-evidence as well as adverse outcomes. It is descriptive only: recurrence without adverse impact cannot promote a finding, and repeated expected behavior is evidence against anomaly.
- Prefer NO_HARNESS_OBSERVATION when the only finding is expected policy behavior or ordinary project work. Do not promote a candidate merely because it could recur in other projects.
- A runtime_observability authoritative fact is concrete decision-useful evidence. Prefer it over a weaker recovered retry-label or harmless policy observation, and use its measured duration and progress count exactly.

Before answering, actively try to falsify the observation: check for an intentional harness policy, a model or project-level cause, successful downstream verification, and absence of user-visible impact. If those explain the evidence, return NO_HARNESS_OBSERVATION. If uncertainty remains but no adverse impact is directly shown, classify it as a candidate.

External scout policy:
- The packet's scout_policy is deterministic harness policy. Search the web only when it says enabled, and only after the local packet supports a concrete harness observation.
- When scout_policy is enabled and a concrete local observation exists, make at least one focused search before answering. If search itself fails, report no imported technique rather than hiding the local observation.
- external_scout_context contains bounded leads retained from earlier successful scouts. Reuse a lead only when its mechanism matches the current evidence, and refresh it with current primary evidence rather than treating memory as authority.
- Use no more than scout_policy.max_searches focused searches. Start from its generic mechanism topics, prefer material published on or after scout_policy.recency_after, and prefer primary engineering posts, papers, repositories, benchmarks, or issue threads with traces over popularity.
- HN, Reddit, and social posts are discovery or counter-evidence unless they contain reproducible artifacts. Follow their links to the canonical source when possible.
- Never put project names, user text, paths, source excerpts, credentials, or other packet-specific material in a search query. Search only for the generalized harness mechanism.
- External material proposes a candidate; it cannot establish that this turn had a problem or that a change should be accepted. Put one falsifiable imported idea in SCOUT_TECHNIQUE and cite its sources in Proposed experiment. If search finds nothing applicable, use SCOUT_TECHNIQUE: none.
]]

function self_research.analysis_prompt(packet)
	local safe_packet = {}
	for key, value in pairs(packet or {}) do
		if key ~= "credentials_path" then safe_packet[key] = value end
	end
	return "Analyse this LCA turn packet:\n\n```json\n" .. json.encode(safe_packet) .. "\n```"
end

local function canonical_read_cap_analysis(fact)
	local batches = {}
	for _, item in ipairs(type(fact.hits_by_batch) == "table" and fact.hits_by_batch or {}) do
		batches[#batches + 1] = string.format("batch %s: %d", tostring(item.batch_id), tonumber(item.hits) or 0)
	end
	local distribution = #batches > 0 and table.concat(batches, ", ") or "batch identity unavailable"
	return table.concat({
		"# Harness observation",
		"",
		"## Evidence",
		string.format("Authoritative fact `read_output_cap`: %d reads were deferred (%s).", tonumber(fact.hits) or 0, distribution),
		string.format("%d deferred reads were followed by a successful read of the same path. Extra model calls are not proven.", tonumber(fact.same_path_recovery_hits) or 0),
		string.format("The declared policy strategy is `%s` with a %s-byte shared cap.", tostring(fact.strategy or "unknown"), tostring(fact.max_bytes or "unknown")),
		"",
		"## Harness hypothesis",
		"Whole-result deferral may discard useful evidence near the shared limit, but this turn does not establish net inefficiency.",
		"",
		"## Proposed experiment",
		"Compare whole-result deferral with remaining-budget truncation on identical seeded tasks. Measure deferred reads, recovery reads, model calls, tokens, and task outcome.",
		"",
		"## Confidence",
		"High confidence in the counts and policy; medium confidence that a different allocation would improve efficiency.",
	}, "\n")
end

local function canonical_runtime_analysis(fact)
	local duration_ms = tonumber(fact.max_duration_ms) or 0
	local duration = string.format("%.1fs", duration_ms / 1000)
	return table.concat({
		"# Harness observation",
		"",
		"## Evidence",
		string.format("Authoritative fact `runtime_observability`: %d foreground run(s) exceeded %.0fs without any progress event.",
			tonumber(fact.count) or 0, (tonumber(fact.threshold_ms) or SILENT_TOOL_THRESHOLD_MS) / 1000),
		"The longest silent interval was " .. duration .. ". The command ultimately finishing does not remove that measured visibility gap.",
		"",
		"## Harness hypothesis",
		"Foreground commands can continue correctly while the TUI receives no evidence with which to evolve its verification state, making active work appear stuck.",
		"",
		"## Proposed experiment",
		"Replay the same long command with bounded elapsed-time/output-growth heartbeats. Compare maximum time between visible state updates, event volume, cancellation behavior, and final task outcome.",
		"",
		"## Confidence",
		"High confidence in the measured duration and absence of progress events; the best heartbeat cadence still requires comparison.",
	}, "\n")
end

function self_research.classify_analysis(value, facts)
	local analysis = trim(redact(value), 16000):gsub("^%s+", ""):gsub("%s+$", "")
	if analysis == "" then return "error", "self-research provider returned no text" end
	local runtime = type(facts) == "table" and type(facts.runtime_observability) == "table"
		and facts.runtime_observability or nil
	local initial_subject = analysis:lower()
	if runtime and (analysis:match("^NO_HARNESS_OBSERVATION")
		or not (initial_subject:find("progress", 1, true) or initial_subject:find("silent", 1, true)
			or initial_subject:find("duration", 1, true) or initial_subject:find("long-running", 1, true))) then
		local canonical = canonical_runtime_analysis(runtime)
		local summary = string.format("Run gave no visible progress for %.1fs", (tonumber(runtime.max_duration_ms) or 0) / 1000)
		return "candidate", canonical, "candidate", summary, "observed", "high"
	end
	if analysis:match("^NO_HARNESS_OBSERVATION") then return "none", "NO_HARNESS_OBSERVATION" end
	local significance = analysis:match("^SIGNIFICANCE:%s*([%w_-]+)")
	local impact = analysis:match("\nIMPACT:%s*([%w_-]+)")
	local confidence = analysis:match("\nCONFIDENCE:%s*([%w_-]+)")
	local summary = analysis:match("\nSUMMARY:%s*([^\r\n]+)")
	local technique = analysis:match("\nSCOUT_TECHNIQUE:%s*([^\r\n]+)")
	analysis = analysis:gsub("^SIGNIFICANCE:[^\r\n]*\r?\nIMPACT:[^\r\n]*\r?\nCONFIDENCE:[^\r\n]*\r?\nSUMMARY:[^\r\n]*\r?\nSCOUT_TECHNIQUE:[^\r\n]*\r?\n+", "")
	analysis = analysis:gsub("^SIGNIFICANCE:[^\r\n]*\r?\nIMPACT:[^\r\n]*\r?\nCONFIDENCE:[^\r\n]*\r?\nSUMMARY:[^\r\n]*\r?\n+", "")
	if not summary or summary == "" or (significance ~= "significant" and significance ~= "candidate")
		or (impact ~= "observed" and impact ~= "potential")
		or (confidence ~= "high" and confidence ~= "medium" and confidence ~= "low") then
		return "none", "NO_HARNESS_OBSERVATION"
	end
	summary = trim(redact(summary), 80):gsub("[\r\n]+", " ")
	if technique then
		technique = trim(redact(technique), 240):gsub("[\r\n]+", " ")
		if technique:lower() == "none" then technique = nil end
	end
	local read_cap = type(facts) == "table" and type(facts.read_output_cap) == "table" and facts.read_output_cap or nil
	local subject = (summary .. "\n" .. analysis):lower()
	if read_cap and subject:find("read", 1, true)
		and (subject:find("budget", 1, true) or subject:find("output cap", 1, true)) then
		local canonical = canonical_read_cap_analysis(read_cap)
		local canonical_summary = string.format("Shared read-output cap deferred %d reads; impact unproven", tonumber(read_cap.hits) or 0)
		return "candidate", canonical, "candidate", canonical_summary, "potential", "medium", technique
	end
	local admission = type(facts) == "table" and type(facts.admission) == "table" and facts.admission or nil
	if significance == "significant" and admission and admission.significant_supported ~= true then
		significance, impact, confidence = "candidate", "potential", "medium"
		analysis = "_Deterministic admission gate: observed significant impact was not established._\n\n" .. analysis
	end
	local status = significance == "significant" and impact == "observed" and confidence == "high"
		and "ready" or "candidate"
	return status, analysis, significance, summary, impact, confidence, technique
end

function self_research.propose_experiment(packet, status)
	packet = type(packet) == "table" and packet or {}
	if status ~= "candidate" and status ~= "ready" then return nil end
	local facts = type(packet.authoritative_facts) == "table" and packet.authoritative_facts or {}
	local pairing = type(facts.native_tool_pairing) == "table" and facts.native_tool_pairing or nil
	if pairing and pairing.pair_closure_required == true then
		return {
			version = 1,
			kind = "session_override",
			key = "native_tool_pair_closure",
			baseline = false,
			challenger = true,
			title = "Keep native tool calls and outputs pair-atomic",
			hypothesis = "Validating pair closure before submission prevents the observed provider rejection while preserving task completion.",
			metrics = { "task_outcome", "tool_errors", "model_calls", "verification" },
		}
	end
	local fact = type(facts.read_output_cap) == "table" and facts.read_output_cap or nil
	if fact then
		local baseline = tonumber(fact.max_bytes) or 24000
		return {
			version = 1,
			kind = "session_override",
			key = "read_batch_bytes",
			baseline = baseline,
			challenger = math.min(96000, math.max(baseline + 1000, baseline * 2)),
			title = "Give concurrent reads more shared context room",
			hypothesis = "A larger shared read-result budget reduces deferred rereads without harming task correctness.",
			metrics = { "task_outcome", "verification", "deferred_reads", "model_calls", "tokens" },
		}
	end
	return nil
end

local function scout_result(response, policy, technique)
	policy = type(policy) == "table" and policy or { enabled = false }
	local searched, search_calls = false, 0
	for _, item in ipairs(type(response) == "table" and type(response._output_items) == "table" and response._output_items or {}) do
		if tostring(item.type or "") == "web_search_call" then
			searched, search_calls = true, search_calls + 1
		end
	end
	local sources, seen = {}, {}
	for url in tostring(response and response.text or ""):gmatch("https?://[^%)>%s]+") do
		local clean_url = url:gsub("[%],%.]+$", "")
		if not seen[clean_url] then seen[clean_url] = true; sources[#sources + 1] = clean_url end
	end
	return {
		version = 1,
		admitted = policy.enabled == true,
		reason = policy.reason,
		recency_after = policy.recency_after,
		max_searches = policy.max_searches,
		searched = searched,
		search_calls = search_calls,
		technique = technique,
		sources = sources,
	}
end

function self_research.run_worker(packet_path, result_path)
	local body = assert(read_file(packet_path), "cannot read turn packet")
	local packet = json.decode(body)
	local providers = require("agent.providers")
	local provider = providers.load(packet.credentials_path)
	local policy = type(packet.scout_policy) == "table" and packet.scout_policy or { enabled = false }
	local response = provider.complete({
		credentials_path = packet.credentials_path,
		session_id = packet.session_id .. "-self-research-" .. tostring(packet.turn or 0),
		model = packet.model,
		reasoning_effort = "low",
		service_tier = packet.service_tier,
		native_tool_calling = true,
		tool_scope = policy.enabled == true and "web_only" or "none",
		system_prompt = ANALYSIS_SYSTEM_PROMPT,
		messages = { { role = "user", text = self_research.analysis_prompt(packet) } },
		max_retries = 0,
		deadlines = { first_byte = 25, idle = 20, total = 60 },
	}, nil)
	local protocol = require("agent.tool_protocol")
	local analysis = protocol.strip_tool_results(protocol.strip_tool_calls(response and response.text or ""))
	local status, classified, significance, summary, impact, confidence, technique = self_research.classify_analysis(analysis, packet.authoritative_facts)
	analysis = classified
	local experiment = self_research.propose_experiment(packet, status)
	local scout = scout_result(response, policy, technique)
	assert(atomic_write(result_path, json.encode({
		status = status,
		analysis = analysis,
		significance = significance,
		summary = summary,
		impact = impact,
		confidence = confidence,
		experiment = experiment,
		scout = scout,
	})))
	return status
end

local function remove_bundle(bundle)
	if not bundle or bundle == "" then return end
	for _, name in ipairs({ "packet.json", "analysis.md", "experiment.json", "scout.json", "result.json", "occurrence.json" }) do
		pcall(uv.fs_unlink, bundle .. "/" .. name)
	end
	pcall(uv.fs_rmdir, bundle)
end

local function default_spawn(spec, done)
	local args = {}
	for _, value in ipairs(spec.worker_args or {}) do args[#args + 1] = value end
	args[#args + 1] = "--packet"
	args[#args + 1] = spec.packet_path
	args[#args + 1] = "--result"
	args[#args + 1] = spec.result_path
	local handle
	handle = uv.spawn(spec.worker_program, { args = args, stdio = { nil, nil, nil } }, function(code, signal)
		if handle and not handle:is_closing() then handle:close() end
		done(code, signal)
	end)
	if not handle then return nil, "failed to start self-research worker" end
	return {
		kill = function(_, signal)
			if handle and not handle:is_closing() then handle:kill(signal or "sigterm") end
		end,
	}
end

local Controller = {}
Controller.__index = Controller

function Controller.new(options)
	options = options or {}
	return setmetatable({
		inbox = assert(options.inbox, "self-research inbox is required"),
		worker_program = assert(options.worker_program, "self-research worker program is required"),
		worker_args = options.worker_args or {},
		spawn_worker = options.spawn_worker or default_spawn,
		on_state = options.on_state,
		active = nil,
		latest = nil,
		significant = nil,
		latest_recurrence = nil,
		sequence = 0,
	}, Controller)
end

function Controller:_emit(status, detail)
	if self.on_state then self.on_state(status, detail) end
end

function Controller:start(packet)
	if self.active then self:cancel("superseded") end
	local ok, err = mkdir_p(self.inbox)
	if not ok then return nil, err end
	local occurrences = self_research.classify_occurrences(packet)
	local prior_recurrence = self_research.recurrence_for(self.inbox, occurrences)
	packet.recurrence_context = #prior_recurrence > 0 and prior_recurrence or nil
	packet.scout_policy = self_research.scout_policy(packet)
	packet.external_scout_context = self_research.recent_external_scouts(self.inbox)
	self.sequence = self.sequence + 1
	local name = string.format("%s-%d-%02d", os.date("%Y%m%d-%H%M%S"), uv.getpid(), self.sequence)
	local bundle = self.inbox .. "/" .. name
	local made, mkdir_err = mkdir_p(bundle)
	if not made then return nil, mkdir_err end
	local packet_path = bundle .. "/packet.json"
	local result_path = bundle .. "/result.json"
	local wrote, write_err = atomic_write(packet_path, json.encode(packet))
	if not wrote then remove_bundle(bundle); return nil, write_err end

	local active = {
		bundle = bundle,
		packet = packet,
		occurrences = occurrences,
		packet_path = packet_path,
		result_path = result_path,
		cancelled = false,
	}
	self.active = active
	self:_emit(packet.scout_policy.enabled and "scouting" or "running", {
		bundle = bundle,
		scout = packet.scout_policy,
	})
	local worker, spawn_err = self.spawn_worker({
		worker_program = self.worker_program,
		worker_args = self.worker_args,
		packet_path = packet_path,
		result_path = result_path,
	}, function(code, signal)
		if self.active ~= active then return end
		self.active = nil
		if active.cancelled then
			remove_bundle(bundle)
			self:_emit("cancelled", { reason = active.reason or "input" })
			return
		end
		local result_body = read_file(result_path)
		local decoded
		if result_body then pcall(function() decoded = json.decode(result_body) end) end
		if code ~= 0 or type(decoded) ~= "table" or decoded.status == "error" then
			remove_bundle(bundle)
			self:_emit("error", { error = decoded and decoded.analysis or "worker exited " .. tostring(code) .. "/" .. tostring(signal) })
			return
		end
		local occurrences = active.occurrences
		local recurrence = {}
		if type(decoded.scout) == "table" then
			atomic_write(bundle .. "/scout.json", json.encode(decoded.scout))
			if decoded.scout.searched == true then
				local research_root = self.inbox:match("^(.*)/[^/]+$") or self.inbox
				append_file(research_root .. "/external-scouts.jsonl", json.encode({
					version = 1,
					created_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
					bundle = bundle,
					reason = decoded.scout.reason,
					technique = decoded.scout.technique,
					sources = decoded.scout.sources,
				}) .. "\n")
			end
		end
		if #occurrences > 0 then
			atomic_write(bundle .. "/occurrence.json", json.encode(recurrence_record(occurrences)))
			recurrence = self_research.recurrence_for(self.inbox, occurrences)
			self.latest_recurrence = {
				bundle = bundle,
				analysis = "No decision-useful harness observation in the latest turn.",
				recurrence = recurrence,
				occurrences = occurrences,
			}
		end
		if decoded.status == "none" then
			atomic_write(bundle .. "/analysis.md", tostring(decoded.analysis or "NO_HARNESS_OBSERVATION"))
			self:_emit("none", { bundle = bundle, recurrence = recurrence, occurrences = occurrences, scout = decoded.scout })
			return
		end
		atomic_write(bundle .. "/analysis.md", tostring(decoded.analysis or ""))
		if type(decoded.experiment) == "table" then
			atomic_write(bundle .. "/experiment.json", json.encode(decoded.experiment))
		end
		local detail = {
			bundle = bundle,
			analysis_path = bundle .. "/analysis.md",
			analysis = tostring(decoded.analysis or ""),
			significance = decoded.significance,
			summary = decoded.summary,
			impact = decoded.impact,
			confidence = decoded.confidence,
			experiment = type(decoded.experiment) == "table" and decoded.experiment or nil,
			recurrence = recurrence,
			occurrences = occurrences,
			scout = decoded.scout,
		}
		self.latest = detail
		if decoded.status == "candidate" then
			self:_emit("candidate", detail)
			return
		end
		self.significant = detail
		self:_emit("ready", detail)
	end)
	if not worker then
		self.active = nil
		remove_bundle(bundle)
		self:_emit("error", { error = spawn_err })
		return nil, spawn_err
	end
	active.worker = worker
	return true, bundle
end

function Controller:cancel(reason)
	local active = self.active
	if not active then return false end
	self.active = nil
	active.cancelled = true
	active.reason = reason or "input"
	if active.worker then active.worker:kill("sigterm") end
	remove_bundle(active.bundle)
	self:_emit("cancelled", { reason = active.reason })
	return true
end

function Controller:latest_analysis()
	return self.significant or self.latest
end

function Controller:latest_experiment()
	-- Never reach behind the newest observation for an unrelated old challenger.
	if self.latest then
		if type(self.latest.experiment) == "table" then return self.latest end
		return nil
	end
	if self.significant and type(self.significant.experiment) == "table" then return self.significant end
	return nil
end

function Controller:recurrence_view()
	return self.latest_recurrence
end

self_research.Controller = Controller
self_research._redact = redact
self_research._remove_bundle = remove_bundle
self_research._analysis_system_prompt = ANALYSIS_SYSTEM_PROMPT

return self_research
