local core = require("agent.core")
local experiment = require("agent.experiment")
local json = require("agent.util.json")

local worker = {}

local function read_json(path)
	local file, err = io.open(path, "r")
	if not file then return nil, err end
	local body = file:read("*a")
	file:close()
	local ok, decoded = pcall(json.decode, body)
	if not ok then return nil, decoded end
	return decoded
end

local function write_json(path, value)
	local file, err = io.open(path, "w")
	if not file then return nil, err end
	file:write(json.encode(value), "\n")
	file:close()
	return true
end

function worker.run(packet_path, result_path, on_event, options)
	options = options or {}
	local packet, packet_err = read_json(packet_path)
	if not packet then return nil, packet_err end
	local challenger_session, session_err = experiment.create_session(packet.challenger)
	if not challenger_session then return nil, session_err end
	local cancelled = false
	local function poll_cancel()
		if cancelled then return true end
		if packet.cancel_path then
			local file = io.open(packet.cancel_path, "r")
			if file then file:close(); cancelled = true end
		end
		return cancelled
	end
	local run_core = options.core_run or core.run_session
	if on_event then on_event({ type = "phase", phase = "ready", pid = require("luv").getpid() }) end
	local ok, turn_result, run_err = pcall(function()
		return run_core(challenger_session,
			function() if on_event then on_event({ type = "model" }) end end,
			function(event) if on_event then on_event({ type = "tool", event = event }) end end,
			function(info) if on_event then on_event({ type = "reviewing", info = info }) end end,
			function() poll_cancel() end,
			{ cancelled = poll_cancel }
		)
	end)
	local result
	if not ok then
		result = { status = "error", error = tostring(turn_result) }
	elseif not turn_result then
		result = { status = "error", error = tostring(run_err or "challenger returned no result") }
	else
		result = { status = cancelled and "cancelled" or "complete", turn_result = turn_result }
	end
	local wrote, write_err = write_json(result_path, result)
	if not wrote then return nil, write_err end
	if on_event then on_event({ type = "phase", phase = result.status }) end
	return result
end

return worker
