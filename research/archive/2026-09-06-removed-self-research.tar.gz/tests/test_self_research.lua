#!/usr/bin/env lua

local script_dir = arg[0]:match("^(.*)/[^/]+$") or "."
local project_dir = script_dir .. "/.."
package.path = project_dir .. "/lua/?.lua;" .. project_dir .. "/lua/?/init.lua;" .. package.path
pcall(require, "luarocks.loader")

local json = require("agent.util.json")
local self_research = require("agent.self_research")
local uv = require("luv")

local passed, failed = 0, 0

local function assert_eq(actual, expected, message)
	if actual ~= expected then
		error((message or "values differ") .. "\nexpected: " .. tostring(expected) .. "\nactual: " .. tostring(actual))
	end
end

local function assert_contains(text, needle, message)
	if not tostring(text):find(needle, 1, true) then error((message or "missing text") .. ": " .. needle) end
end

local function test(name, fn)
	io.write("  " .. name .. " ")
	local ok, err = pcall(fn)
	if ok then passed = passed + 1; io.write("\27[32mPASS\27[0m\n")
	else failed = failed + 1; io.write("\27[31mFAIL\27[0m (" .. tostring(err):sub(1, 180) .. ")\n") end
end

local function write(path, value)
	local file = assert(io.open(path, "w"))
	file:write(value)
	file:close()
end

local function read_json(path)
	local file = assert(io.open(path, "r"))
	local value = json.decode(file:read("*a"))
	file:close()
	return value
end

local root = string.format("/tmp/lca-self-research-test-%d", uv.getpid())
assert(uv.fs_mkdir(root, tonumber("755", 8)))

io.write("\n═══ Self Research Tests ═══\n\n")

test("research inbox defaults to a user-local dotfile directory", function()
	local project = root .. "/project"
	assert(uv.fs_mkdir(project, tonumber("755", 8)))
	assert_eq(self_research.resolve_inbox(project, root .. "/chosen", false), root .. "/chosen")
	assert_eq(self_research.default_inbox("/home/example"), "/home/example/.lca/research/inbox")
	assert_eq(self_research.resolve_inbox(project, nil, false), self_research.default_inbox())
	assert(uv.fs_mkdir(project .. "/research", tonumber("755", 8)))
	write(project .. "/research/README.md", "policy")
	assert_eq(self_research.resolve_inbox(project, nil, false), self_research.default_inbox())
end)

test("turn packets are bounded and redact common credentials", function()
	local events = {}
	for index = 1, 90 do events[index] = { name = "read", args = { path = tostring(index) } } end
	local packet = self_research.build_packet({
		credentials_path = "/private/credentials.json",
		prompt = 'Authorization: Bearer secret-token\n{"api_key":"open-sesame"}',
		assistant = string.rep("x", 9000),
		events = { { name = "run", args = { command = "echo safe" }, result = {
			content = "Bearer abc.def " .. string.rep("z", 2500), summary = "exit 0",
			harness_policy = { name = "scheduler", strategy = "declared", rationale = "preserve correctness", group_size = 2 },
		} } },
	})
	assert_contains(packet.prompt, "[REDACTED]")
	assert_eq(packet.prompt:find("secret%-token"), nil)
	assert(#packet.assistant < 9100)
	assert(#packet.events[1].result.content < 2200)
	assert_eq(packet.events[1].result.harness_policy.rationale, "preserve correctness")
	local bounded = self_research.build_packet({ events = events })
	assert_eq(#bounded.events, 65)
	assert_eq(bounded.events[33].name, "events_omitted")
	local prompt = self_research.analysis_prompt(packet)
	assert_eq(prompt:find("/private/credentials.json", 1, true), nil)
end)

test("analyzer knows the intentional fast-tool lifecycle contract", function()
	assert_contains(self_research._analysis_system_prompt, "Tool start events are optional progress signals")
	assert_contains(self_research._analysis_system_prompt, "may intentionally have only a finish event")
	assert_contains(self_research._analysis_system_prompt, "omitted from the text transcript")
end)

test("external scout is bounded, recent, and admitted by evidence or curiosity", function()
	local failed_turn = self_research.build_packet({
		session_id = "failed-session",
		turn = 2,
		outcome = "error",
		transcript = "context hard limit stopped",
	})
	local admitted = self_research.scout_policy(failed_turn, { now = 1788134400, sample_percent = 0 })
	assert_eq(admitted.enabled, true)
	assert_eq(admitted.reason, "observed harness failure")
	assert_eq(admitted.max_searches, 3)
	assert_eq(admitted.recency_after, "2026-05-03")

	local routed = self_research.build_packet({
		session_id = "curious-session",
		turn = 4,
		context_compactions = 1,
	})
	local curious = self_research.scout_policy(routed, { sample_percent = 100 })
	assert_eq(curious.enabled, true)
	assert_eq(curious.reason, "bounded curiosity sample")
	assert_contains(table.concat(curious.topics, "\n"), "context reset")
	assert_eq(self_research.scout_policy(routed, { sample_percent = 0 }).enabled, false)
end)

test("scout instructions keep searches generic and evidence subordinate", function()
	assert_contains(self_research._analysis_system_prompt, "Never put project names")
	assert_contains(self_research._analysis_system_prompt, "External material proposes a candidate")
	assert_contains(self_research._analysis_system_prompt, "no more than scout_policy.max_searches")
	assert_contains(self_research._analysis_system_prompt, "make at least one focused search")
	assert_contains(self_research._analysis_system_prompt, "external_scout_context")
	local status, _, _, _, _, _, technique = self_research.classify_analysis(table.concat({
		"SIGNIFICANCE: candidate",
		"IMPACT: potential",
		"CONFIDENCE: medium",
		"SUMMARY: Tool output may consume avoidable context",
		"SCOUT_TECHNIQUE: retain a retrieval handle for truncated output",
		"# Harness observation",
		"## Evidence",
	}, "\n"))
	assert_eq(status, "candidate")
	assert_eq(technique, "retain a retrieval handle for truncated output")
end)

test("mutation signals include bounded provenance for relevant harness code", function()
	local paths = {
		["agent.parallel"] = project_dir .. "/lua/agent/parallel.lua",
		["agent.tools.edit"] = project_dir .. "/lua/agent/tools/edit.lua",
	}
	local packet = self_research.build_packet({
		events = { { name = "edit", args = { path = "example.lua" }, result = {
			harness_policy = { name = "non_overlapping_same_file_edits", strategy = "descending_source_position" },
		} } },
		source_resolver = function(name) return paths[name] end,
	})
	assert_eq(packet.version, 3)
	assert_eq(packet.harness_context.routes[1], "mutations")
	assert_contains(table.concat(packet.harness_context.invariants, "\n"), "bottom-up")
	assert_eq(packet.harness_context.sources[1].module, "agent.parallel")
	assert_contains(packet.harness_context.sources[1].hash, "fnv1a32:")
	assert_contains(packet.harness_context.sources[1].excerpt, "safe_tagged_edit_group")
	assert(#json.encode(packet.harness_context) <= 16000)
end)

test("read-cap facts are deterministic and route the governing policy", function()
	local function cap(batch, path, index)
		return {
			name = "read", batch_id = batch, model_call_id = batch, model_index = index,
			args = { path = path, offset = 1, limit = 300 },
			result = {
				summary = "read budget reached",
				content = "Read batch output budget reached (24000 bytes).",
				harness_policy = {
					name = "shared_read_output_cap",
					strategy = "sequential_model_order_shared_budget",
					max_bytes = 24000,
				},
			},
		}
	end
	local events = {
		cap(1, "a.lua", 3), cap(1, "b.lua", 4),
		{ name = "read", batch_id = 2, args = { path = "a.lua" }, result = { summary = "20 lines", content = "source" } },
		{ name = "read", batch_id = 2, args = { path = "b.lua" }, result = { summary = "20 lines", content = "source" } },
		cap(3, "c.lua", 2), cap(3, "d.lua", 3), cap(3, "e.lua", 4),
		{ name = "read", batch_id = 4, args = { path = "c.lua" }, result = { summary = "20 lines", content = "source" } },
	}
	local packet = self_research.build_packet({ events = events })
	local fact = packet.authoritative_facts.read_output_cap
	assert_eq(fact.hits, 5)
	assert_eq(fact.hits_by_batch[1].batch_id, 1)
	assert_eq(fact.hits_by_batch[1].hits, 2)
	assert_eq(fact.hits_by_batch[2].batch_id, 3)
	assert_eq(fact.hits_by_batch[2].hits, 3)
	assert_eq(fact.same_path_recovery_hits, 3)
	assert_eq(fact.extra_model_calls_proven, false)
	assert_eq(fact.strategy, "sequential_model_order_shared_budget")
	assert_eq(packet.harness_context.routes[1], "reads")
	assert_contains(table.concat(packet.harness_context.invariants, "\n"), "sequentially in model order")
	assert_contains(packet.harness_context.sources[1].excerpt, "MAX_READ_BATCH_BYTES")
	local experiment = self_research.propose_experiment(packet, "candidate")
	assert_eq(experiment.kind, "session_override")
	assert_eq(experiment.key, "read_batch_bytes")
	assert_eq(experiment.baseline, 24000)
	assert_eq(experiment.challenger, 48000)
	assert_eq(self_research.propose_experiment(packet, "none"), nil)
end)

test("silent long runs become deterministic observability evidence", function()
	local events = {
		{ phase = "start", name = "run", call_id = "run-1", args = { command = "make test" }, observed_at_ms = 100 },
		{ phase = "finish", name = "run", call_id = "run-1", args = { command = "make test" },
			duration_ms = 42100, observed_at_ms = 42200, result = { summary = "exit 0", is_error = false } },
	}
	local packet = self_research.build_packet({ session_id = "silent-session", turn = 4, events = events })
	local fact = packet.authoritative_facts.runtime_observability
	assert_eq(fact.count, 1)
	assert_eq(fact.max_duration_ms, 42100)
	assert_eq(fact.silent_tools[1].progress_events, 0)
	assert_eq(packet.authoritative_facts.admission.reasons[1], "long_running_tool_without_progress")
	assert_contains(table.concat(packet.harness_context.routes, "\n"), "observability")
	assert_contains(table.concat(packet.harness_context.invariants, "\n"), "progress heartbeats")
	local scout = self_research.scout_policy(packet, { sample_percent = 0 })
	assert_eq(scout.enabled, true)
	assert_eq(scout.reason, "observed runtime observability gap")
	assert_contains(table.concat(scout.topics, "\n"), "long running command progress")
	local occurrences = self_research.classify_occurrences(packet)
	assert_eq(occurrences[1].fingerprint, "observability.silent_long_tool.foreground_run_without_progress")
	assert_eq(occurrences[1].outcome, "adverse")
	local status, analysis, significance, summary, impact, confidence =
		self_research.classify_analysis("NO_HARNESS_OBSERVATION", packet.authoritative_facts)
	assert_eq(status, "candidate")
	assert_eq(significance, "candidate")
	assert_eq(impact, "observed")
	assert_eq(confidence, "high")
	assert_contains(summary, "42.1s")
	assert_contains(analysis, "without any progress event")
end)

test("progress heartbeats falsify a silent-run observation", function()
	local packet = self_research.build_packet({ events = {
		{ phase = "start", name = "run", call_id = "run-2" },
		{ phase = "progress", name = "run", call_id = "run-2", progress = { elapsed_ms = 12000, output_bytes = 0, output_chunks = 0 } },
		{ phase = "finish", name = "run", call_id = "run-2", duration_ms = 42000, result = { summary = "exit 0" } },
	} })
	assert_eq(packet.authoritative_facts.runtime_observability, nil)
	assert_eq(packet.harness_context, nil)
end)

test("unsupported read-cap analysis is replaced by authoritative evidence", function()
	local packet = self_research.build_packet({
		events = {
			{ name = "read", batch_id = 1, args = { path = "a.lua" }, result = {
				summary = "read budget reached",
				harness_policy = { name = "shared_read_output_cap", strategy = "sequential_model_order_shared_budget", max_bytes = 24000 },
			} },
		},
	})
	local bad = table.concat({
		"SIGNIFICANCE: significant",
		"IMPACT: observed",
		"CONFIDENCE: high",
		"SUMMARY: Shared read-output cap skipped six reads and forced extra calls",
		"# Harness observation",
		"## Evidence",
		"Six reads were skipped by parallel completion order and forced another call.",
	}, "\n")
	local status, analysis, significance, summary, impact, confidence =
		self_research.classify_analysis(bad, packet.authoritative_facts)
	assert_eq(status, "candidate")
	assert_eq(significance, "candidate")
	assert_eq(impact, "potential")
	assert_eq(confidence, "medium")
	assert_contains(summary, "deferred 1 reads")
	assert_contains(analysis, "Extra model calls are not proven")
	assert_eq(analysis:find("Six reads", 1, true), nil)
	assert_eq(analysis:find("completion order", 1, true), nil)
end)

test("significance requires deterministic admission evidence", function()
	local finding = table.concat({
		"SIGNIFICANCE: significant",
		"IMPACT: observed",
		"CONFIDENCE: high",
		"SUMMARY: A plausible but unproven harness failure",
		"# Harness observation",
	}, "\n")
	local status, analysis, significance, _, impact, confidence = self_research.classify_analysis(finding, {
		admission = { significant_supported = false, reasons = {} },
	})
	assert_eq(status, "candidate")
	assert_eq(significance, "candidate")
	assert_eq(impact, "potential")
	assert_eq(confidence, "medium")
	assert_contains(analysis, "admission gate")
end)

test("provider orphan output becomes an executable pair-closure experiment", function()
	local packet = self_research.build_packet({
		outcome = "error",
		transcript = table.concat({
			"[context] slim audit messages=4 bytes_removed=46111",
			"HTTP 400 No tool call found for function call output with call_id call_example.",
		}, "\n"),
	})
	local fact = packet.authoritative_facts.native_tool_pairing
	assert_eq(fact.id, "orphan_function_call_output")
	assert_eq(fact.context_slimming_observed, true)
	local proposal = self_research.propose_experiment(packet, "ready")
	assert_eq(proposal.key, "native_tool_pair_closure")
	assert_eq(proposal.challenger, true)
end)

test("latest experiment never falls back to an unrelated older finding", function()
	local controller = self_research.Controller.new({
		inbox = "/tmp/lca-research-controller-test",
		worker_program = "true",
	})
	controller.significant = { experiment = { key = "read_batch_bytes" } }
	controller.latest = { summary = "new finding without an executable challenger" }
	assert_eq(controller:latest_experiment(), nil)
	controller.latest = nil
	assert_eq(controller:latest_experiment().experiment.key, "read_batch_bytes")
end)

test("ordinary turns and single edits do not expose unrelated harness source", function()
	local packet = self_research.build_packet({
		events = {
			{ name = "read", args = { path = "README.md" } },
			{ name = "edit", args = { path = "README.md" }, result = { summary = "replaced one line" } },
		},
		transcript = "ordinary successful work",
	})
	assert_eq(packet.harness_context, nil)
end)

test("create then refine is not treated as suspicious same-file recurrence", function()
	local packet = self_research.build_packet({
		events = {
			{ name = "write", args = { path = "requirements.txt" }, result = { summary = "wrote 2 lines" } },
			{ name = "read", args = { path = "requirements.txt" }, result = { summary = "2 lines" } },
			{ name = "edit", args = { path = "requirements.txt" }, result = { summary = "replaced 2 lines" } },
		},
		transcript = "ordinary successful refinement",
	})
	assert_eq(packet.harness_context, nil)
	assert_eq(#self_research.classify_occurrences(packet), 0)
end)

test("only well-formed significant observations stay pinned", function()
	local status, analysis, significance, summary = self_research.classify_analysis(table.concat({
		"SIGNIFICANCE: significant",
		"IMPACT: observed",
		"CONFIDENCE: high",
		"SUMMARY: Cancellation can leave a live worker behind",
		"# Harness observation",
		"## Evidence",
	}, "\n"))
	assert_eq(status, "ready")
	assert_eq(significance, "significant")
	assert_eq(summary, "Cancellation can leave a live worker behind")
	assert_contains(analysis, "# Harness observation")
	local candidate = self_research.classify_analysis(table.concat({
		"SIGNIFICANCE: significant",
		"IMPACT: potential",
		"CONFIDENCE: high",
		"SUMMARY: Scheduling might affect an edit",
		"# Harness observation",
	}, "\n"))
	assert_eq(candidate, "candidate")
	assert_eq(self_research.classify_analysis("generic suggestion"), "none")
	assert_eq(self_research.classify_analysis("NO_HARNESS_OBSERVATION"), "none")
end)

test("recurrence fingerprints come from structured mechanism rather than model prose", function()
	local packet = self_research.build_packet({
		session_id = "session-a",
		turn = 3,
		events = {
			{ name = "edit", args = { path = "app.lua", start_line = 20 }, result = {
				summary = "edited", harness_policy = { name = "same_file", strategy = "descending_source_position" },
			} },
			{ name = "edit", args = { path = "app.lua", start_line = 10 }, result = {
				summary = "edited", harness_policy = { name = "same_file", strategy = "descending_source_position" },
			} },
			{ name = "run", args = { command = "make test" }, result = { summary = "exit 0", is_error = false } },
		},
	})
	local occurrences = self_research.classify_occurrences(packet)
	assert_eq(#occurrences, 1)
	assert_eq(occurrences[1].fingerprint, "mutations.same_file_group.descending_source_position")
	assert_eq(occurrences[1].outcome, "verified")
	assert_eq(occurrences[1].session_id, "session-a")
	assert_contains(occurrences[1].harness_hash, "fnv1a32:")
end)

test("recurrence counts independent sessions and retains counter-evidence", function()
	local inbox = root .. "/recurrence-inbox"
	assert(uv.fs_mkdir(inbox, tonumber("755", 8)))
	local fingerprint = "mutations.same_file_group.descending_source_position"
	local samples = {
		{ dir = "001", session = "session-a", outcome = "verified" },
		{ dir = "002", session = "session-a", outcome = "harmless" },
		{ dir = "003", session = "session-b", outcome = "adverse" },
	}
	for _, sample in ipairs(samples) do
		local bundle = inbox .. "/" .. sample.dir
		assert(uv.fs_mkdir(bundle, tonumber("755", 8)))
		write(bundle .. "/occurrence.json", json.encode({ version = 1, occurrences = { {
			fingerprint = fingerprint,
			session_id = sample.session,
			outcome = sample.outcome,
			created_at = "2026-08-24T00:00:0" .. sample.dir:sub(-1) .. "Z",
			harness_hash = "fnv1a32:12345678",
		} } }))
	end
	local recurrence = self_research.recurrence_for(inbox, { { fingerprint = fingerprint } })
	assert_eq(#recurrence, 1)
	assert_eq(recurrence[1].total, 3)
	assert_eq(recurrence[1].independent_sessions, 2)
	assert_eq(recurrence[1].outcomes.verified, 1)
	assert_eq(recurrence[1].outcomes.harmless, 1)
	assert_eq(recurrence[1].outcomes.adverse, 1)
	local formatted = self_research.format_recurrence(recurrence)
	assert_contains(formatted, "descriptive only")
	assert_contains(formatted, "3 occurrences across 2 sessions")
	assert_contains(formatted, "adverse 1")
	assert_contains(formatted, "verified 1")
	for _, sample in ipairs(samples) do
		uv.fs_unlink(inbox .. "/" .. sample.dir .. "/occurrence.json")
		uv.fs_rmdir(inbox .. "/" .. sample.dir)
	end
	uv.fs_rmdir(inbox)
end)

local function controller_fixture()
	local inbox = root .. "/inbox-" .. tostring(math.random(100000, 999999))
	local pending, killed, states = nil, false, {}
	local controller = self_research.Controller.new({
		inbox = inbox,
		worker_program = "fake-worker",
		spawn_worker = function(spec, done)
			pending = { spec = spec, done = done }
			return { kill = function() killed = true end }
		end,
		on_state = function(status) states[#states + 1] = status end,
	})
	return controller, function() return pending end, function() return killed end, states, inbox
end

test("completed analysis is retained as a reviewable bundle", function()
	local controller, pending, _, states, inbox = controller_fixture()
	local ok, bundle = controller:start(self_research.build_packet({ prompt = "hello" }))
	assert_eq(ok, true)
	assert(uv.fs_stat(bundle .. "/packet.json"))
	write(pending().spec.result_path, json.encode({
		status = "ready",
		analysis = "# Harness observation\nEvidence",
		significance = "significant",
		summary = "Cancellation can leave a live worker behind",
		impact = "observed",
		confidence = "high",
	}))
	pending().done(0, 0)
	assert_eq(states[1], "running")
	assert_eq(states[#states], "ready")
	assert(uv.fs_stat(bundle .. "/analysis.md"))
	assert_eq(controller:latest_analysis().bundle, bundle)
	assert_eq(controller:latest_analysis().significance, "significant")
	self_research._remove_bundle(bundle)
	uv.fs_rmdir(inbox)
end)

test("candidate observations are retained without becoming pinned", function()
	local controller, pending, _, states, inbox = controller_fixture()
	local _, bundle = controller:start(self_research.build_packet({ prompt = "hello" }))
	write(pending().spec.result_path, json.encode({
		status = "candidate",
		analysis = "# Harness observation\nPotential only",
		significance = "candidate",
		summary = "Scheduling might affect an edit",
		impact = "potential",
		confidence = "medium",
		experiment = { kind = "session_override", key = "read_batch_bytes", challenger = 48000 },
	}))
	pending().done(0, 0)
	assert_eq(states[#states], "candidate")
	assert(uv.fs_stat(bundle .. "/analysis.md"))
	assert(uv.fs_stat(bundle .. "/experiment.json"))
	assert_eq(controller:latest_analysis().summary, "Scheduling might affect an edit")
	assert_eq(controller:latest_experiment().experiment.challenger, 48000)
	self_research._remove_bundle(bundle)
	uv.fs_rmdir(inbox)
end)

test("completed scouts retain technique provenance in the bundle and research memory", function()
	local controller, pending, _, states, inbox = controller_fixture()
	local packet = self_research.build_packet({
		prompt = "hello",
		outcome = "error",
		transcript = "tool budget exhausted",
	})
	local _, bundle = controller:start(packet)
	assert_eq(states[1], "scouting")
	write(pending().spec.result_path, json.encode({
		status = "candidate",
		analysis = "# Harness observation\nPotential only",
		significance = "candidate",
		summary = "Tool output may consume avoidable context",
		impact = "potential",
		confidence = "medium",
		scout = {
			version = 1,
			admitted = true,
			searched = true,
			search_calls = 2,
			reason = "observed harness failure",
			technique = "retain a retrieval handle for truncated output",
			sources = { "https://example.com/primary" },
		},
	}))
	pending().done(0, 0)
	assert(uv.fs_stat(bundle .. "/scout.json"))
	local memory_path = root .. "/external-scouts.jsonl"
	local memory_file = assert(io.open(memory_path, "r"))
	local memory = json.decode(memory_file:read("*l"))
	memory_file:close()
	assert_contains(memory.technique, "retain a retrieval handle")
	assert_eq(memory.sources[1], "https://example.com/primary")
	local _, next_bundle = controller:start(self_research.build_packet({ prompt = "another turn" }))
	local next_packet = read_json(next_bundle .. "/packet.json")
	assert_eq(next_packet.external_scout_context[1].technique, "retain a retrieval handle for truncated output")
	assert_eq(next_packet.external_scout_context[1].sources[1], "https://example.com/primary")
	write(pending().spec.result_path, json.encode({ status = "none", analysis = "NO_HARNESS_OBSERVATION" }))
	pending().done(0, 0)
	self_research._remove_bundle(bundle)
	self_research._remove_bundle(next_bundle)
	uv.fs_rmdir(inbox)
	uv.fs_unlink(memory_path)
end)

test("a later analyzer packet receives prior recurrence but not its current occurrence", function()
	local controller, pending, _, _, inbox = controller_fixture()
	local function packet(session_id)
		return self_research.build_packet({
			session_id = session_id,
			events = { { name = "edit", args = { path = "app.lua" }, result = {
				summary = "edited", harness_policy = { strategy = "descending_source_position" },
			} } },
		})
	end
	local _, first_bundle = controller:start(packet("session-a"))
	assert_eq(read_json(first_bundle .. "/packet.json").recurrence_context, nil)
	write(pending().spec.result_path, json.encode({ status = "none", analysis = "NO_HARNESS_OBSERVATION" }))
	pending().done(0, 0)

	local _, second_bundle = controller:start(packet("session-b"))
	local second_packet = read_json(second_bundle .. "/packet.json")
	assert_eq(second_packet.recurrence_context[1].total, 1)
	assert_eq(second_packet.recurrence_context[1].independent_sessions, 1)
	write(pending().spec.result_path, json.encode({ status = "none", analysis = "NO_HARNESS_OBSERVATION" }))
	pending().done(0, 0)
	assert_eq(controller:recurrence_view().recurrence[1].total, 2)
	assert_eq(controller:recurrence_view().recurrence[1].independent_sessions, 2)

	self_research._remove_bundle(first_bundle)
	self_research._remove_bundle(second_bundle)
	uv.fs_rmdir(inbox)
end)

test("typing cancels immediately and a late child exit is harmless", function()
	local controller, pending, killed, states, inbox = controller_fixture()
	local _, bundle = controller:start(self_research.build_packet({ prompt = "hello" }))
	assert_eq(controller:cancel("typing"), true)
	assert_eq(killed(), true)
	assert_eq(uv.fs_stat(bundle), nil)
	assert_eq(states[#states], "cancelled")
	pending().done(143, 15)
	assert_eq(states[#states], "cancelled")
	uv.fs_rmdir(inbox)
end)

test("empty findings retain the evidence snapshot without claiming a finding", function()
	local controller, pending, _, states, inbox = controller_fixture()
	local _, bundle = controller:start(self_research.build_packet({
		prompt = "hello",
		session_id = "quiet-session",
		events = { { name = "edit", args = { path = "app.lua" }, result = {
			summary = "edited", harness_policy = { strategy = "descending_source_position" },
		} } },
	}))
	write(pending().spec.result_path, json.encode({ status = "none", analysis = "NO_HARNESS_OBSERVATION" }))
	pending().done(0, 0)
	assert_eq(states[#states], "none")
	assert(uv.fs_stat(bundle .. "/packet.json"))
	assert(uv.fs_stat(bundle .. "/analysis.md"))
	assert(uv.fs_stat(bundle .. "/occurrence.json"))
	assert_eq(controller:recurrence_view().recurrence[1].total, 1)
	self_research._remove_bundle(bundle)
	uv.fs_rmdir(inbox)
end)

test("worker entrypoint returns its startup error to the controller", function()
	local result_path = root .. "/worker-error.json"
	local missing_packet = root .. "/missing-packet.json"
	local command = string.format("lua5.5 %q --packet %q --result %q >/dev/null 2>&1", project_dir .. "/bin/self-research.lua", missing_packet, result_path)
	os.execute(command)
	local file = assert(io.open(result_path, "r"))
	local result = json.decode(file:read("*a"))
	file:close()
	assert_eq(result.status, "error")
	assert_contains(result.analysis, "cannot read turn packet")
	uv.fs_unlink(result_path)
end)

uv.fs_unlink(root .. "/project/research/README.md")
uv.fs_rmdir(root .. "/project/research")
uv.fs_rmdir(root .. "/project")
uv.fs_rmdir(root)

io.write(string.format("\n%d passed, %d failed\n", passed, failed))
if failed > 0 then os.exit(1) end
