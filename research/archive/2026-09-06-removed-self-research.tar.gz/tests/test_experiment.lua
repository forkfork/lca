#!/usr/bin/env lua

local script_dir = arg[0]:match("^(.*)/[^/]+$") or "."
local project_dir = script_dir .. "/.."
package.path = project_dir .. "/lua/?.lua;" .. project_dir .. "/lua/?/init.lua;" .. package.path
pcall(require, "luarocks.loader")

local experiment = require("agent.experiment")
local experiment_worker = require("agent.experiment_worker")
local json = require("agent.util.json")
local session_module = require("agent.session")
local uv = require("luv")

local function assert_eq(actual, expected)
	if actual ~= expected then error("expected " .. tostring(expected) .. ", got " .. tostring(actual)) end
end

local function write_file(path, body)
	local output = assert(io.open(path, "w"))
	output:write(body)
	output:close()
end

local source = string.format("/tmp/lca-experiment-fixture-%d", uv.getpid())
uv.fs_mkdir(source, tonumber("700", 8))
local file = assert(io.open(source .. "/state.txt", "w"))
file:write("before\n")
file:close()

local base_session = session_module.create({ session_id = "experiment-test", read_batch_bytes = 24000 })
base_session.messages = { { role = "user", text = "prior context" } }
local checkpoint = assert(experiment.capture({
	cwd = source,
	engine_root = project_dir,
	prompt = "perform the task",
	session = base_session:serialize(),
}))

local pointer_path = source .. "/engine-source"
write_file(pointer_path, project_dir .. "\n")
assert_eq(experiment.resolve_engine_root(nil, { pointer_path = pointer_path }), project_dir)
assert(experiment._owned_root(checkpoint.root))
assert_eq(checkpoint.engine.root, project_dir)
assert_eq(checkpoint.engine.generation, "A")
local manifest = json.decode(assert(io.open(checkpoint.manifest_path, "r")):read("*a"))
assert_eq(manifest.active_generation, "A")
assert_eq(manifest.project.authoritative, source)
local captured = assert(io.open(checkpoint.base .. "/state.txt", "r")):read("*a")
assert_eq(captured, "before\n")

local live = assert(io.open(source .. "/state.txt", "w"))
live:write("after A\n")
live:close()
local proposal = {
	kind = "session_override", key = "read_batch_bytes", baseline = 24000, challenger = 48000,
}
local challenger = assert(experiment.prepare_challenger(checkpoint, proposal))
assert(uv.fs_stat(challenger.engine_workspace .. "/lua/agent/core.lua"))
local replayed = assert(io.open(challenger.workspace .. "/state.txt", "r")):read("*a")
assert_eq(replayed, "before\n")
local configured = session_module.create({ session_id = "challenger" })
assert(experiment.configure_session(configured, challenger))
assert_eq(configured.cwd, challenger.workspace)
assert_eq(configured.read_batch_bytes, 48000)
local pair_session = session_module.create({ session_id = "pair-challenger", native_tool_pair_closure = false })
local pair_challenger = {
	workspace = challenger.workspace,
	proposal = { kind = "session_override", key = "native_tool_pair_closure", challenger = true },
}
assert(experiment.configure_session(pair_session, pair_challenger))
assert_eq(pair_session.native_tool_pair_closure, true)
local replay_session = assert(experiment.create_session(challenger))
assert_eq(replay_session.cwd, challenger.workspace)
assert_eq(replay_session.read_batch_bytes, 48000)
assert_eq(replay_session.messages[1].text, "prior context")
assert_eq(replay_session.messages[2].text, "perform the task")

local worker_packet = checkpoint.root .. "/worker-packet.json"
local worker_result = checkpoint.root .. "/worker-result.json"
write_file(worker_packet, json.encode({ version = 1, challenger = challenger }))
local worker_events = {}
local completed = assert(experiment_worker.run(worker_packet, worker_result, function(event)
	worker_events[#worker_events + 1] = event
end, {
	core_run = function(child_session, _, on_tool)
		assert_eq(child_session.cwd, challenger.workspace)
		assert_eq(child_session.read_batch_bytes, 48000)
		on_tool({ phase = "complete", name = "read", result = { summary = "ok" } })
		return { text = "worker complete", events = {} }
	end,
}))
assert_eq(completed.status, "complete")
assert_eq(completed.turn_result.text, "worker complete")
assert_eq(worker_events[1].phase, "ready")
assert_eq(json.decode(assert(io.open(worker_result, "r")):read("*a")).status, "complete")

-- Replace only B's runner with a deterministic fixture. If run_challenger
-- accidentally launches the installed or authoritative runner this test would
-- attempt a real model request instead of producing this marker.
write_file(challenger.engine_workspace .. "/bin/experiment-runner.lua", [=[
local script_dir = arg[0]:match("^(.*)/[^/]+$") or "."
local project_dir = script_dir .. "/.."
package.path = project_dir .. "/lua/?.lua;" .. project_dir .. "/lua/?/init.lua;" .. package.path
pcall(require, "luarocks.loader")
local json = require("agent.util.json")
local uv = require("luv")
local result_path
for index = 1, #arg do
	if arg[index] == "--result" then result_path = arg[index + 1] end
end
local marker = assert(io.open("spawned-cwd.txt", "w"))
marker:write(uv.cwd(), "\n", arg[0], "\n")
marker:close()
io.stdout:write(json.encode({ type = "phase", phase = "ready", pid = uv.getpid() }), "\n")
io.stdout:flush()
local output = assert(io.open(result_path, "w"))
output:write(json.encode({ status = "complete", turn_result = { text = "child complete", events = {} } }), "\n")
output:close()
]=])
local child_events = {}
local child_result = assert(experiment.run_challenger(challenger, {
	on_event = function(event) child_events[#child_events + 1] = event end,
}))
assert_eq(child_result.status, "complete")
assert_eq(child_result.turn_result.text, "child complete")
assert_eq(child_events[1].phase, "ready")
local marker = assert(io.open(challenger.workspace .. "/spawned-cwd.txt", "r")):read("*a")
local spawned_cwd, spawned_runner = marker:match("([^\n]+)\n([^\n]+)")
assert_eq(spawned_cwd, challenger.workspace)
assert_eq(spawned_runner, challenger.engine_workspace .. "/bin/experiment-runner.lua")

local summary = experiment.summarize({
	text = "done",
	events = {
		{ model_call_id = 1, name = "read", result = { summary = "read budget reached" } },
		{ model_call_id = 2, name = "run", args = { command = "make test" }, result = { summary = "exit 0" } },
	},
	_turn_usage = { prompt_tokens = 1200, total_tokens = 1400 },
})
assert_eq(summary.outcome, "complete")
assert_eq(summary.deferred_reads, 1)
assert_eq(summary.model_calls, 2)
assert_eq(summary.verification, "exit 0")
local verdict, winner = experiment.verdict({ deferred_reads = 2, tool_errors = 0, verification = "exit 0" }, {
	outcome = "complete", deferred_reads = 0, tool_errors = 0, verification = "exit 0",
})
assert_eq(verdict, "B promising · deferred reads 2 → 0")
assert_eq(winner, "b")
local recovered_verdict, recovered_winner = experiment.verdict({ outcome = "error" }, { outcome = "complete", tool_errors = 0 })
assert_eq(recovered_verdict, "B promising · recovered task completion")
assert_eq(recovered_winner, "b")

local implementation = assert(experiment.prepare_implementation(checkpoint, {
	analysis = "The read cap deferred useful evidence.",
	experiment = proposal,
}, {
	winner = "b",
	verdict = verdict,
	baseline = { deferred_reads = 2 },
	challenger = { deferred_reads = 0 },
}))
assert_eq(implementation.engine_root, project_dir)
assert_eq(implementation.project_root, source)
local implementation_prompt = assert(experiment.implementation_prompt(implementation))
assert(implementation_prompt:find("Do not edit it", 1, true))
assert(implementation_prompt:find('"read_batch_bytes"', 1, true))
local implementation_session = assert(experiment.create_implementation_session(implementation, base_session))
assert_eq(implementation_session.cwd, project_dir)
assert(implementation_session.messages[1].text:find("authoritative LCA engine checkout", 1, true))
assert(implementation_session:get_system_prompt():find("make local", 1, true))
local validation_call
local validation = assert(experiment.validate_implementation(implementation, {
	run_process = function(program, args, on_wait, cwd)
		validation_call = { program = program, args = args, cwd = cwd }
		return true
	end,
}))
assert_eq(validation.command, "make check")
assert_eq(validation_call.program, "make")
assert_eq(validation_call.args[1], "check")
assert_eq(validation_call.cwd, project_dir)
local failed_validation, failed_validation_err = experiment.validate_implementation(implementation, {
	run_process = function() return nil, "injected adjacent failure" end,
})
assert_eq(failed_validation, nil)
assert(failed_validation_err:find("adjacent regression gate failed", 1, true))
local rejected = experiment.prepare_implementation(checkpoint, { experiment = proposal }, { winner = "a" })
assert_eq(rejected, nil)

assert(experiment.cleanup(checkpoint))
assert_eq(uv.fs_stat(checkpoint.root), nil)
local refused = experiment.cleanup(source)
assert_eq(refused, nil)
os.remove(source .. "/state.txt")
os.remove(pointer_path)
uv.fs_rmdir(source)

io.write("experiment checkpoint and challenger boundary PASS\n")
