import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "evals"))
import repository_facts
import prompt_profiles


class RepositoryFactsTests(unittest.TestCase):
    def probe(self, cwd, env=None):
        script = '''package.path = "./lua/?.lua;./lua/?/init.lua;" .. package.path
require("luarocks.loader")
local facts = dofile("evals/repository_facts.lua")
local value = facts.probe(arg[1])
io.write(require("agent.util.json").encode({facts=value, text=facts.text(value)}))
'''
        result = subprocess.run([shutil.which("lua"), "-", str(cwd)], input=script, cwd=ROOT, env=env, capture_output=True, text=True, check=True)
        return json.loads(result.stdout)

    def test_actual_git_and_non_git_workspaces_and_quoted_paths(self):
        with tempfile.TemporaryDirectory(prefix="lca-git-facts-") as tmp:
            workspace = Path(tmp) / "space ' dollar $ parentheses ()"; workspace.mkdir()
            outside = self.probe(workspace)
            self.assertEqual(outside["facts"]["state"], "outside")
            repository_facts.audit(outside["facts"], workspace)
            subprocess.run(["git", "init", "-q", str(workspace)], check=True)
            nested = workspace / "nested"; nested.mkdir()
            inside = self.probe(nested)
            self.assertEqual(inside["facts"]["state"], "inside")
            repository_facts.audit(inside["facts"], workspace)
            for data in (inside, outside):
                self.assertEqual(data["text"], repository_facts.text(data["facts"]))
                self.assertEqual(prompt_profiles.apply("fixed prompt", "repo-facts", data["facts"]), "fixed prompt" + data["text"])
            with self.assertRaises(ValueError): repository_facts.audit(outside["facts"], workspace)
            broken = dict(inside["facts"], output="false")
            with self.assertRaises(ValueError): repository_facts.audit(broken, workspace)

    def test_saved_workspace_does_not_inherit_harness_git_repository(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "evals/results", prefix="git-facts-audit-") as tmp:
            workspace = Path(tmp)
            repository_facts.audit({"state": "outside", "output": "fatal: not a git repository", "exit_code": 128}, workspace)

    def test_missing_git_and_probe_failure_are_not_reported_as_non_git(self):
        with tempfile.TemporaryDirectory() as tmp:
            env = dict(os.environ, PATH=tmp)
            missing = self.probe(tmp, env)
            self.assertEqual(missing["facts"]["state"], "unavailable")
            failed = self.probe(Path(tmp) / "absent")
            self.assertEqual(failed["facts"]["state"], "unknown")
            for data in (missing, failed):
                self.assertEqual(data["text"], repository_facts.text(data["facts"]))
                with self.assertRaises(ValueError): repository_facts.audit(data["facts"], Path(tmp))
            with self.assertRaises(ValueError): prompt_profiles.apply("fixed", "repo-facts")
