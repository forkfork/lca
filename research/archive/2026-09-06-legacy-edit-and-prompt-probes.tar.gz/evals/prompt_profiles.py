"""Independent activation audit for supported eval prompt profiles."""
import json

PROFILES = {"current", "repo-facts"}


def apply(full, profile, repository=None):
    if profile not in PROFILES:
        raise ValueError("unsupported audited prompt profile")
    if profile == "current":
        return full
    if profile == "repo-facts":
        from repository_facts import text
        return full + text(repository)


def audit(directory, profile, requests, trajectory):
    snapshot = json.loads((directory / "prompt-profile.json").read_text())
    if snapshot["profile"] != profile or trajectory.get("system_prompt_profile") != profile:
        raise ValueError("prompt profile activation mismatch")
    expected = apply(snapshot["baseline"], profile, snapshot.get("repository"))
    if profile == "repo-facts":
        from repository_facts import audit
        audit(snapshot["repository"], directory / "workspace")
    if snapshot["effective"] != expected:
        raise ValueError("prompt snapshot mismatch")
    for request in requests:
        if json.loads(request.read_text()).get("system_prompt") != expected:
            raise ValueError("outgoing prompt activation mismatch")
