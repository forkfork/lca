-- Eval-only observed environment facts. No workflow advice or production default.
local shell = require("agent.util.shell")
local inventory = require("agent.runtime_inventory")
local M = {}

function M.probe(cwd)
	local git = inventory.resolve("git")
	if not git then return { state = "unavailable", cwd = cwd, output = "", exit_code = 127 } end
	local command = "LC_ALL=C " .. shell.quote(git) .. " -C " .. shell.quote(cwd)
		.. " rev-parse --is-inside-work-tree 2>&1"
	local handle = io.popen(command)
	if not handle then return { state = "unknown", cwd = cwd, output = "probe could not start", exit_code = -1 } end
	local output = handle:read("*a") or ""
	local ok, _, code = handle:close()
	local trimmed = output:match("^%s*(.-)%s*$")
	local state = "unknown"
	if ok and trimmed == "true" then state = "inside"
	elseif (ok and trimmed == "false") or (not ok and output:find("not a git repository", 1, true)) then state = "outside" end
	return { state = state, cwd = cwd, output = output, exit_code = ok and 0 or (code or -1) }
end

function M.text(facts)
	local labels = {
		inside = "The working directory is inside a Git work tree.",
		outside = "The working directory is not inside a Git work tree.",
		unavailable = "The git executable is unavailable on the startup PATH.",
		unknown = "The Git work-tree probe failed; repository status is unknown.",
	}
	return "\n\n## Repository facts (observed at task start)\n" .. assert(labels[facts.state]) .. "\n"
end
return M
