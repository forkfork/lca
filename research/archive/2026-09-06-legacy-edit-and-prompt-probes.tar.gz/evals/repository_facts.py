"""Independent repository-fact rendering and post-run activation audit."""
import subprocess
import os

LABELS = {
    "inside": "The working directory is inside a Git work tree.",
    "outside": "The working directory is not inside a Git work tree.",
    "unavailable": "The git executable is unavailable on the startup PATH.",
    "unknown": "The Git work-tree probe failed; repository status is unknown.",
}


def text(facts):
    if not isinstance(facts, dict) or facts.get("state") not in LABELS:
        raise ValueError("missing/invalid repository facts")
    return "\n\n## Repository facts (observed at task start)\n" + LABELS[facts["state"]] + "\n"


def audit(facts, workspace):
    text(facts)
    state, output, code = facts["state"], facts.get("output", "").strip(), facts.get("exit_code")
    if state not in {"inside", "outside"}:
        raise ValueError("repository fact treatment did not obtain a definite observation")
    if state == "inside" and (code != 0 or output != "true"):
        raise ValueError("repository fact contradicts probe")
    if state == "outside" and not ((code == 0 and output == "false") or (code != 0 and "not a git repository" in output)):
        raise ValueError("repository fact contradicts probe")
    # Preserved artifacts live under LCA's Git checkout, unlike the task's
    # isolated /tmp directory. Do not discover that unrelated parent repository.
    environment = dict(os.environ, LC_ALL="C", GIT_CEILING_DIRECTORIES=str(workspace.resolve().parent))
    for name in ("GIT_DIR", "GIT_WORK_TREE", "GIT_COMMON_DIR"):
        environment.pop(name, None)
    result = subprocess.run(["git", "-C", str(workspace), "rev-parse", "--is-inside-work-tree"], env=environment, capture_output=True, text=True, timeout=10)
    if not workspace.is_dir() or (result.returncode != 0 and "not a git repository" not in result.stderr):
        raise ValueError("preserved workspace probe failed")
    inside = result.returncode == 0 and result.stdout.strip() == "true"
    if inside != (state == "inside"):
        raise ValueError("repository fact differs from preserved workspace")
