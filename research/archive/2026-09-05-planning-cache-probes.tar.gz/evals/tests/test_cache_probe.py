import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cache_probe import grade,stream_output,transform
class CacheProbeTests(unittest.TestCase):
    def test_completed_output_can_be_empty_after_streamed_answer(self):
        response={'status':'completed','output':{},'usage':{'input_tokens':42}}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'stream.jsonl'
            p.write_text(json.dumps({'type':'response.output_item.done','item':{'type':'message','content':[{'type':'output_text','text':'391'}]}})+'\n'+json.dumps({'type':'response.completed','response':response})+'\n')
            self.assertTrue(grade(response,'simple_prompt',stream_output(p)))
            p.write_text(p.read_text().replace('391','392'))
            self.assertFalse(grade(response,'simple_prompt',stream_output(p)))
        self.assertFalse(grade(response,'existing_codebase_edit',[{'type':'function_call'}]))
    def test_treatment_changes_only_options(self):
        raw={'model':'gpt-6-astra','input':[{'role':'user','content':[]}]}
        a=transform(raw,False,'same');b=transform(raw,True,'same')
        self.assertEqual(a,{k:v for k,v in b.items() if k!='prompt_cache_options'})
        self.assertNotIn('prompt_cache_key',raw)
