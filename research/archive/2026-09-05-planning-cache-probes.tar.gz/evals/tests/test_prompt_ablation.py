import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "evals"))
import prompt_ablation
import test_campaign


class PromptAblationTests(unittest.TestCase):
    def test_lua_and_python_agree_on_real_prompt_and_preserve_project_instructions(self):
        script = '''package.path = "./lua/?.lua;./lua/?/init.lua;" .. package.path
require("luarocks.loader")
local json = require("agent.util.json")
local full = require("agent.system_prompt").build({cwd="evals/scenarios/ambiguous_bug_investigation/fixture", model="gpt-6-astra"})
local f = assert(io.open("evals/prompt_ablation.json"))
local spec = json.decode(f:read("*a")); f:close()
local project = "\\n# Project Context\\n" .. spec.remove_lines[1] .. "\\n"
full = full .. project
local slim = dofile("evals/prompt_ablation.lua").apply(full, spec)
local ablation = dofile("evals/prompt_ablation.lua")
assert(not pcall(ablation.apply, "missing", spec))
assert(not pcall(ablation.apply, spec.remove_lines[1] .. "\\n" .. full, spec))
io.write(json.encode({full=full, slim=slim}))
'''
        result = subprocess.run(["lua", "-"], input=script, cwd=ROOT, text=True, capture_output=True, check=True)
        data = json.loads(result.stdout)
        self.assertEqual(prompt_ablation.apply(data["full"], "current"), data["full"])
        self.assertEqual(prompt_ablation.apply(data["full"], "workflow-lite"), data["slim"])
        self.assertLess(len(data["slim"]), len(data["full"]))
        for protected in ("## Verification sufficiency", "call update_plan at most once", "Preserve existing project patterns and user changes", "four-character tags", "Runtime:"):
            self.assertIn(protected, data["slim"])
        self.assertEqual(data["full"].split("\n# Project Context\n", 1)[1], data["slim"].split("\n# Project Context\n", 1)[1])

    def test_planning_clarification_preserves_baseline_and_project_context(self):
        spec_path = ROOT / "evals/planning_clarification.json"
        line = json.loads(spec_path.read_text())["append_lines"][0]
        script = '\n'.join([
            'package.path = "./lua/?.lua;./lua/?/init.lua;" .. package.path',
            'require("luarocks.loader")',
            'local json = require("agent.util.json")',
            'local full = require("agent.system_prompt").build({cwd="evals/scenarios/existing_codebase_edit/fixture", model="gpt-6-astra"})',
            'local f = assert(io.open("evals/planning_clarification.json"))',
            'local spec = json.decode(f:read("*a")); f:close()',
            'io.write(json.encode({full=full, effective=dofile("evals/prompt_ablation.lua").apply(full,spec)}))',
        ])
        data = json.loads(subprocess.check_output(["lua", "-"], input=script, text=True, cwd=ROOT))
        effective = prompt_ablation.apply(data["full"], "planning-clarity")
        self.assertEqual(effective, data["effective"])
        self.assertEqual(effective.count(line), 1)
        self.assertEqual(effective.replace("\n" + line + "\n", "", 1), data["full"])
        self.assertIn("Prefer a small set of realistic tests", effective)
        self.assertEqual(effective.partition("\n# Project Context\n")[2], data["full"].partition("\n# Project Context\n")[2])

    def test_missing_duplicate_and_unknown_profiles_fail_closed(self):
        lines = json.loads(prompt_ablation.SPEC.read_text())["remove_lines"]
        full = "\n".join(lines) + "\n"
        prompt_ablation.apply(full, "workflow-lite")
        for text, profile in (("", "workflow-lite"), (full + lines[0] + "\n", "workflow-lite"), (full, "lean")):
            with self.assertRaises(ValueError):
                prompt_ablation.apply(text, profile)

    def test_campaign_audits_every_outgoing_prompt(self):
        import campaign
        helper = test_campaign.CampaignTests()
        baseline = "\n".join(json.loads(prompt_ablation.SPEC.read_text())["remove_lines"]) + "\nprotected\n"
        for profile in ("current", "workflow-lite", "planning-clarity"):
            with self.subTest(profile=profile), tempfile.TemporaryDirectory() as tmp:
                directory = Path(tmp)
                cell = helper.manifest()["cells"][0]
                cell["variant"]["system_prompt_profile"] = profile
                helper.evidence(directory, cell)
                effective = prompt_ablation.apply(baseline, profile)
                campaign.save(directory / "prompt-profile.json", {"profile": profile, "baseline": baseline, "effective": effective})
                trajectory = campaign.read(directory / "trajectory.json")
                trajectory["system_prompt_profile"] = profile
                campaign.save(directory / "trajectory.json", trajectory)
                request = campaign.read(directory / "request-0001.json")
                request["system_prompt"] = effective
                campaign.save(directory / "request-0001.json", request)
                self.assertTrue(campaign.inspect_result(directory, cell)["passed"])
                request["system_prompt"] += "unexpected instruction"
                campaign.save(directory / "request-0001.json", request)
                with self.assertRaisesRegex(ValueError, "prompt activation"):
                    campaign.inspect_result(directory, cell)


if __name__ == "__main__":
    unittest.main()
