"""Independent activation audit for the eval-only procedural prompt ablation."""
import json
from pathlib import Path

SPEC = Path(__file__).with_suffix(".json")
PROFILES = {"current", "workflow-lite", "repo-facts", "planning-clarity"}


def apply(full, profile, repository=None):
    if profile not in PROFILES:
        raise ValueError("unsupported audited prompt profile")
    if profile == "current":
        return full
    if profile == "repo-facts":
        from repository_facts import text
        return full + text(repository)
    prefix, marker, suffix = full.partition("\n# Project Context\n")
    spec_path = SPEC.with_name("planning_clarification.json") if profile == "planning-clarity" else SPEC
    specification = json.loads(spec_path.read_text())
    for line in specification["remove_lines"]:
        needle = line + "\n"
        if prefix.count(needle) != 1 or needle not in ("\n" + prefix):
            raise ValueError("ablation source line missing or duplicated")
        before, after = prefix.split(needle)
        if before and not before.endswith("\n"):
            raise ValueError("ablation source is not a full line")
        prefix = before + after
    if "append_lines" in specification:
        prefix += "\n" + "\n".join(specification["append_lines"]) + "\n"
    return prefix + marker + suffix


def audit(directory, profile, requests, trajectory):
    snapshot = json.loads((directory / "prompt-profile.json").read_text())
    if snapshot["profile"] != profile or trajectory.get("system_prompt_profile") != profile:
        raise ValueError("prompt profile activation mismatch")
    expected = apply(snapshot["baseline"], profile, snapshot.get("repository"))
    if profile == "repo-facts":
        from repository_facts import audit
        audit(snapshot["repository"], directory / "workspace")
    if snapshot["effective"] != expected:
        raise ValueError("prompt snapshot mismatch")
    for request in requests:
        if json.loads(request.read_text()).get("system_prompt") != expected:
            raise ValueError("outgoing prompt activation mismatch")
