-- Read-only wire probe. Sends one frozen request twice; never executes model tools.
local root, directory = assert(arg[1]), assert(arg[2])
package.path = root .. '/lua/?.lua;' .. root .. '/lua/?/init.lua;' .. package.path
require('luarocks.loader')
local json = require('agent.util.json')
local ws = require('agent.net.websocket_transport')
local providers = require('agent.providers')
local socket = require('socket')
local function read(path)
 local f=assert(io.open(path)); local s=f:read('*a'); f:close(); return s
end
local function save(name, value)
 local f=assert(io.open(directory .. '/' .. name,'w')); f:write(json.encode(value),'\n'); f:close()
end
local body=json.decode(read(directory .. '/request.json'))
local auth=json.decode(providers.credentials_body(require('agent.config').default_credentials_path()))
local conn,err=ws.connect({host='chatgpt.com',port=443,path='/backend-api/codex/responses',
 user_agent='lca-codex/websocket',deadlines={connect=10,tls=10,write=10,first_byte=15,idle=30,total=60},
 headers={{'Authorization','Bearer '..assert(auth.access)},{'chatgpt-account-id',assert(auth.accountId)},
 {'originator','lca'},{'OpenAI-Beta','responses_websockets=2026-02-06'},
 {'session-id',body.prompt_cache_key},{'thread-id',body.prompt_cache_key},{'x-client-request-id',body.prompt_cache_key}}})
if not conn then save('error.json',err); os.exit(1) end
local ok,failure=pcall(function()
 for n=1,2 do
  local f=assert(io.open(directory .. '/response-'..n..'.jsonl','w'))
  local complete,server_error
  local start=socket.gettime()
  body.type='response.create'
  save('wire-request-'..n..'.json',body)
  local worked,transport_result=pcall(function()
   return conn:request(json.encode(body),function(payload)
    f:write(payload,'\n'); f:flush()
    local e=json.decode(payload)
    if e.type=='response.completed' then complete=e.response; return false end
    if e.type=='error' or e.type=='response.failed' or e.type=='response.incomplete' then server_error=e; return false end
   end)
  end)
  f:close()
  if not worked then error(transport_result) end
  if server_error then save('server-error.json',server_error); error('server rejected request') end
  assert(complete,'missing completed response')
  save('completed-'..n..'.json',complete)
  save('timing-'..n..'.json',{elapsed_seconds=socket.gettime()-start,transport=transport_result})
  assert(complete.usage,'missing usage')
  for _,item in ipairs(complete.output or {}) do assert(item.type~='function_call','unexpected tool call; no tools executed') end
  if body.prompt_cache_options then
   assert(type(complete.prompt_cache_options)=='table','cache options were not acknowledged in response; activation unknown')
   assert(complete.prompt_cache_options.mode==body.prompt_cache_options.mode,'cache mode activation mismatch')
  end
 end
end)
conn:close()
if not ok then save('error.json',{error=tostring(failure)}); os.exit(1) end
