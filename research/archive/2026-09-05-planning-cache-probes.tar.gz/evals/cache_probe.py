"""Bounded read-only cache capability screen on frozen request tails."""
import hashlib
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import sys
import time
import campaign
ROOT=Path(__file__).resolve().parents[1]
THEORY=ROOT/'evals/theories/astra_cache_options_screen_v2.json'
D=ROOT/'evals/results/20260905-astra-cache-options-screen-v2'

def transform(body,options,key):
    body=json.loads(json.dumps(body))
    body['prompt_cache_key']=key
    if options: body['prompt_cache_options']={'mode':'implicit','ttl':'30m'}
    return body

def stream_output(path):
    return [e["item"] for line in path.read_text().splitlines()
            if (e := json.loads(line)).get("type") == "response.output_item.done"]

def grade(response,scenario,items=None):
    if response.get('status')!='completed' or not response.get('usage'): return False
    items=response.get('output',[]) if items is None else items
    if any(i.get('type')=='function_call' for i in items): return False
    answer=''.join(c.get('text','') for i in items for c in i.get('content',[]) if c.get('type')=='output_text')
    return answer.strip()=='391' if scenario=='simple_prompt' else bool(answer.strip())

def main():
    theory=json.loads(THEORY.read_text()); D.mkdir(exist_ok=False)
    seed=921; rng=random.Random(seed)
    cells=[]
    for scenario,source in theory['frozen_requests'].items():
        pair=[{'scenario':scenario,'arm':arm,'source':source} for arm in ['current','cache-options']]
        # Capability baseline must precede treatment on simple control.
        if scenario!='simple_prompt': rng.shuffle(pair)
        cells.extend(pair)
    manifest={'theory':theory,'cells':cells,'source_sha256':campaign.source_digest(),'seed':seed,'requests':{}}
    for i,c in enumerate(cells):
        c['id']=f'cell-{i:04d}'; body=json.loads((ROOT/c['source']).read_text())
        c['source_sha256']=hashlib.sha256((ROOT/c['source']).read_bytes()).hexdigest()
        manifest['requests'][c['id']]=transform(body,c['arm']=='cache-options',f'lca-cache-options-921-{i}')
    campaign.save(D/'manifest.json',manifest)
    with (D/'source.tar').open('wb') as out:
        subprocess.run(['tar','--exclude=__pycache__','--exclude=results','-cf','-','lua','bin','scripts','evals','tests','AGENTS.md','Makefile','lca-dev-1.rockspec'],cwd=ROOT,stdout=out,check=True)
    state={'attempts':[],'estimated_cost_usd':0,'elapsed_seconds':0}
    for c in cells:
        if state['estimated_cost_usd']>=1 or state['elapsed_seconds']>=240: state['halted']='budget'; break
        assert campaign.source_digest()==manifest['source_sha256'],'source drift'
        cell=D/c['id'];cell.mkdir();campaign.save(cell/'request.json',manifest['requests'][c['id']])
        print('RUN',c['id'],c['scenario'],c['arm'],flush=True)
        started=time.monotonic()
        with (cell/'runner.log').open('w') as log:
            p=subprocess.Popen(['lua',str(ROOT/'evals/cache_probe.lua'),str(ROOT),str(cell)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:p.wait(timeout=min(125,240-state['elapsed_seconds']))
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        state['elapsed_seconds']+=time.monotonic()-started
        attempt={**c,'returncode':p.returncode,'responses':[]}
        for path in sorted(cell.glob('completed-*.json')):
            response=json.loads(path.read_text());u=response['usage'];det=u.get('input_tokens_details',{})
            inp=u['input_tokens'];cached=det.get('cached_tokens',0);writes=det.get('cache_write_tokens',0);out=u['output_tokens']
            # Same frozen standard-equivalent estimator as original screen; writes reported separately.
            cost=((inp-cached)*10+cached+out*50)/1e6
            state['estimated_cost_usd']+=cost
            attempt['responses'].append({'usage':u,'passed':grade(response,c['scenario'],stream_output(path.with_name(path.name.replace('completed-','response-').replace('.json','.jsonl')))),'cost_estimate':cost,'cache_options':response.get('prompt_cache_options'),'diagnostics':response.get('prompt_cache_diagnostics')})
            if writes: state['halted']='cache-write billing needs separate accounting'
        state['attempts'].append(attempt)
        if p.returncode or len(attempt['responses'])!=2 or not all(r['passed'] for r in attempt['responses']):state['halted']='protocol, activation, or answer check failed; no scale-up'
        campaign.save(D/'state.json',state)
        print(json.dumps(attempt),flush=True)
        if state.get('halted'):break
    state['complete']=len(state['attempts'])==4 and not state.get('halted');campaign.save(D/'state.json',state)
    return 0 if state['complete'] else 1
if __name__=='__main__':raise SystemExit(main())
