-- Eval-only, exact-line prompt transformations. Never rewrite project instructions or schemas.
local M = {}
function M.apply(full, specification)
	local boundary = full:find("\n# Project Context\n", 1, true) or (#full + 1)
	local prefix, suffix = full:sub(1, boundary - 1), full:sub(boundary)
	for _, line in ipairs(specification.remove_lines) do
		local needle = line .. "\n"
		local first, last = prefix:find(needle, 1, true)
		assert(first and (first == 1 or prefix:sub(first - 1, first - 1) == "\n"), "ablation line missing")
		assert(not prefix:find(needle, last + 1, true), "ablation line duplicated")
		prefix = prefix:sub(1, first - 1) .. prefix:sub(last + 1)
	end
	if specification.append_lines then
		prefix = prefix .. "\n" .. table.concat(specification.append_lines, "\n") .. "\n"
	end
	return prefix .. suffix
end
return M
