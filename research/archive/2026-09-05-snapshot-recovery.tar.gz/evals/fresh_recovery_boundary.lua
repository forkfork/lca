-- Held-out, fully inspected insertion/deletion boundaries. No model calls here.
local json = require("agent.util.json")
local fs = require("agent.util.fs")
local read = require("agent.tools.read")
local registry = require("agent.tool_registry")
local protocol = require("agent.tool_protocol")
local uv = require("luv")
local M = {}
local function encode(args)
	local keys, parts = {}, {}
	for key in pairs(args) do keys[#keys+1]=key end
	table.sort(keys)
	for _,key in ipairs(keys) do parts[#parts+1]=json.encode(key)..":"..json.encode(args[key]) end
	return "{"..table.concat(parts,",").."}"
end
function M.seed(session, spec, external)
	local started=uv.hrtime()
	local original=fs.read_file(session.cwd.."/"..spec.path)
	local lines=read.split_lines(original)
	local function edit(first,last,content,delta)
		return {name="edit",args={path=spec.path,start_line=first+(delta or 0),end_line=last+(delta or 0),
			start_tag=read.line_tag(first,lines[first]),end_tag=read.line_tag(last,lines[last]),content=content}}
	end
	local calls={
		{name="read",args={path="README.md",limit=200}},
		{name="read",args={path=spec.path,limit=200}},
		{name="read",args={path="test_task.py",limit=200}},
		edit(spec.first_start,spec.first_end,spec.first_content),
		edit(spec.original_start,spec.original_end,spec.new_body,spec.delta),
	}
	local events={}
	for index,call in ipairs(calls) do
		if index==#calls and external then
			local target=session.cwd.."/"..spec.path
			fs.write_file(target,fs.read_file(target).."\n# concurrent operator note\n")
		end
		local id="call_fresh_boundary_"..index
		session:add_assistant("",{{type="function_call",name=call.name,arguments=encode(call.args),call_id=id,status="completed"}})
		local result=registry.execute(call.name,call.args,{cwd=session.cwd,session=session})
		if index<#calls then assert(not result.is_error,result.content) end
		session:add_tool_result(call.name,protocol.tool_result_message(call.name,result,call.args),id)
		events[#events+1]={name=call.name,args=call.args,result=result,fixture_seed=true}
	end
	local last=events[#events].result
	assert((last.is_error and last.summary=="stale tag") or last.snapshot_recovery,"fresh boundary did not activate")
	return {kind="fresh_recovery_boundary",events=events,messages=session.messages,body_result=last,
		elapsed_ms=(uv.hrtime()-started)/1e6,delta=spec.delta,external_change=external or false}
end
return M
