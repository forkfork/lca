-- Experimental wrapper, deliberately not installed in the production tool registry.
-- Retain only the immediately preceding successful single tagged edit per session.
local read = require("agent.tools.read")
local fs = require("agent.util.fs")
local path = require("agent.util.path")
local M = {}
local MAX_BYTES = 128 * 1024
local MAX_SHIFT = 200

function M.install(tool)
	local execute = tool.execute
	local receipts = setmetatable({}, { __mode = "k" })
	tool.execute = function(args, context)
		local session = context.session
		if not session then return execute(args, context) end
		local target = args.path and path.resolve(args.path, context.cwd)
		local ok, before = pcall(fs.read_file, target)
		if not ok then before = nil end
		local receipt = session and receipts[session]
		local result = execute(args, context)
		if result.is_error and result.summary == "stale tag" and not args.edits
			and receipt and receipt.target == target and receipt.after == before then
			local first, last = tonumber(args.start_line), tonumber(args.end_line or args.start_line)
			local current = read.split_lines(before)
			local old = read.split_lines(receipt.before)
			local candidate, count = nil, 0
			if first and last and first % 1 == 0 and last % 1 == 0
				and first >= 1 and last >= first and last <= #current then
				for start = math.max(1, first - MAX_SHIFT), math.min(#old, first + MAX_SHIFT) do
					local finish = start + last - first
					if finish <= #old and read.line_tag(start, old[start]) == args.start_tag
						and read.line_tag(finish, old[finish]) == args.end_tag then
						count = count + 1
						candidate = start
					end
				end
				if count == 1 and candidate ~= first then
					local unchanged = true
					for offset = 0, last - first do
						if old[candidate + offset] ~= current[first + offset] then unchanged = false; break end
					end
					-- Identical text elsewhere cannot identify the intended occurrence.
					local occurrences = 0
					if unchanged then
						local needle = "\n" .. table.concat(old, "\n", candidate, candidate + last - first) .. "\n"
						local haystack = "\n" .. table.concat(current, "\n") .. "\n"
						local at = haystack:find(needle, 1, true)
						if at then occurrences = haystack:find(needle, at + 1, true) and 2 or 1 end
					end
					if unchanged and occurrences == 1 then
						local corrected = {}
						for key, value in pairs(args) do corrected[key] = value end
						corrected.start_tag = read.line_tag(first, current[first])
						corrected.end_tag = read.line_tag(last, current[last])
						result = execute(corrected, context)
						if not result.is_error then
							result.summary = result.summary .. ", snapshot tags recovered"
							result.content = result.content .. "; recovered old tags against unchanged source from the preceding LCA edit"
							result.snapshot_recovery = { old_start = candidate, current_start = first }
						end
					end
				end
			end
		end
		if session and not result.is_error then
			receipts[session] = nil
			if args.start_line and not args.edits and before and #before <= MAX_BYTES then
				local after_ok, after = pcall(fs.read_file, target)
				if after_ok and after and #after <= MAX_BYTES and before ~= after then
					receipts[session] = { target = target, before = before, after = after }
				end
			end
		end
		return result
	end
	return tool
end

return M
