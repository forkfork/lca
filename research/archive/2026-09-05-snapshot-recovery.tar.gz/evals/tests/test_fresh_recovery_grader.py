import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from fresh_recovery_grader import grade


class FreshRecoveryGraderTests(unittest.TestCase):
    def test_good_and_corrupt_artifacts_for_each_task(self):
        specs = json.loads((ROOT / "fresh_recovery_fixtures.json").read_text())
        evidence = {"events": [dict(name="edit", result={"is_error": False}),
                              dict(name="run", args={"command": "python3 -m unittest -v"},
                                   result={"is_error": False, "content": "Ran 3 tests in 0.1s\n\nOK\n"})]}
        for name, spec in specs.items():
            with self.subTest(scenario=name), tempfile.TemporaryDirectory() as tmp:
                scenario, workspace = ROOT / "scenarios" / name, Path(tmp)
                shutil.copytree(scenario / "fixture", workspace, dirs_exist_ok=True)
                target = workspace / spec["path"]
                lines = target.read_text().splitlines()
                # Apply intended changes independently, bottom-to-top.
                lines[spec["original_start"]-1:spec["original_end"]] = spec["new_body"].splitlines()
                lines[spec["first_start"]-1:spec["first_end"]] = spec["first_content"].splitlines()
                good = "\n".join(lines) + "\n"
                target.write_text(good)
                self.assertTrue(grade(scenario, workspace, evidence)["passed"])
                bads = ([good.replace("ROUND_HALF_UP))", "'ROUND_DOWN'))"),
                         good.replace("amount < 0", "amount < -1"), good.replace('CURRENCY = "USD"', 'CURRENCY = "EUR"')]
                        if name == "receipt_insert" else
                        [good.replace(".casefold()", ".lower()"), good.replace('" / ".join', '"/".join'),
                         good + '\nLEGACY_PREFIX = "old"\n', good.replace("MAX_LABEL_LENGTH = 120", "MAX_LABEL_LENGTH = 121")])
                for bad in bads:
                    target.write_text(bad)
                    shutil.rmtree(workspace / "__pycache__", ignore_errors=True)
                    self.assertFalse(grade(scenario, workspace, evidence)["passed"])
                target.write_text(good)
                shutil.rmtree(workspace / "__pycache__", ignore_errors=True)
                self.assertFalse(grade(scenario, workspace, {"events": []})["passed"])
                (workspace / "README.md").write_text("changed")
                self.assertFalse(grade(scenario, workspace, evidence)["passed"])
