import importlib.util
import shutil
import tempfile
import unittest
from pathlib import Path

SCENARIO = Path(__file__).resolve().parents[1] / "scenarios/snake_recovery_boundary"
spec = importlib.util.spec_from_file_location("snake_boundary_grader", SCENARIO / "grade.py")
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)


class SnakeBoundaryGraderTests(unittest.TestCase):
    def test_positive_and_independent_negative_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            shutil.copytree(SCENARIO / "fixture", root, dirs_exist_ok=True)
            path = root / "snake.py"
            good = path.read_text().replace("import random", "import math\nimport random").replace(
                "def draw(screen, game, paused):",
                "def wave_offset(phase):\n    return round(3 * math.sin(phase))\n\n\ndef draw(screen, game, paused):")
            evidence = {"events": [dict(name="edit", result={"is_error": False}),
                                  dict(name="run", args={"command": "python3 -m unittest -v"},
                                       result={"is_error": False, "content": "Ran 3 tests in 0.1s\n\nOK\n"})]}
            path.write_text(good)
            self.assertTrue(grader.grade(root, evidence)["passed"])
            for bad in [good.replace("round(3 * math.sin(phase))", "0"),
                        good.replace("round(3 * math.sin(phase))", "round(2 * math.sin(phase))"),
                        good.replace("WIDTH, HEIGHT = 32, 16", "WIDTH, HEIGHT = 33, 16")]:
                path.write_text(bad)
                shutil.rmtree(root / "__pycache__", ignore_errors=True)
                self.assertFalse(grader.grade(root, evidence)["passed"])
            path.write_text(good)
            shutil.rmtree(root / "__pycache__", ignore_errors=True)
            self.assertFalse(grader.grade(root, {"events": []})["passed"])
            (root / "README.md").write_text("changed")
            self.assertFalse(grader.grade(root, evidence)["passed"])
