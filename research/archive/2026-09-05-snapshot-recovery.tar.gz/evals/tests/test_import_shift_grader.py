import importlib.util
import shutil
import tempfile
import unittest
from pathlib import Path

SCENARIO = Path(__file__).resolve().parents[1] / "scenarios/import_shift_edit"
spec = importlib.util.spec_from_file_location("import_shift_grader", SCENARIO / "grade.py")
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)


class ImportShiftGraderTests(unittest.TestCase):
    def test_positive_and_independent_negative_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            shutil.copytree(SCENARIO / "fixture", root, dirs_exist_ok=True)
            path = root / "pricing.py"
            good = path.read_text().replace("import random", "import math\nimport random").replace(
                "    return round(weight_kg / 10)",
                '    if weight_kg < 0:\n        raise ValueError("negative weight")\n    return math.ceil(weight_kg / 10)')
            evidence = {"events": [dict(name="edit", result={"is_error": False}),
                                  dict(name="run", args={"command": "python3 -m unittest -v"},
                                       result={"is_error": False, "content": "Ran 3 tests in 0.1s\n\nOK\n"})]}
            path.write_text(good)
            self.assertTrue(grader.grade(root, evidence)["passed"])
            for bad in [good.replace("math.ceil(weight_kg / 10)", "round(weight_kg / 10)"),
                        good.replace("weight_kg < 0", "weight_kg < -1"),
                        good.replace('CURRENCY = "AUD"', 'CURRENCY = "USD"')]:
                path.write_text(bad)
                shutil.rmtree(root / "__pycache__", ignore_errors=True)
                self.assertFalse(grader.grade(root, evidence)["passed"])
            path.write_text(good)
            shutil.rmtree(root / "__pycache__", ignore_errors=True)
            self.assertFalse(grader.grade(root, {"events": []})["passed"])
            (root / "README.md").write_text("changed")
            self.assertFalse(grader.grade(root, evidence)["passed"])
