"""Freeze, then run a four-cell screen. No resume or promotion path."""
import argparse
import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

THEORY = "astra_snapshot_edit_recovery_screen"


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def plan(out, boundary=False, inspected=False, validation=False):
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "evals"))
    import run
    out.mkdir(parents=True, exist_ok=False)
    support = out / "support"
    support.mkdir()
    for pattern in ("*.py", "*.lua", "*.json"):
        for source in (root / "evals").glob(pattern):
            shutil.copy2(source, support / source.name)
    # The machine's unqualified lua is 5.4; pin the project's 5.5 runtime.
    runtime = Path(shutil.which("lua5.5")).resolve()
    runner = support / "run.py"
    body = runner.read_text()
    old = '"lua", str(EVAL_ROOT / "driver.lua"),'
    assert body.count(old) == 1
    runner.write_text(body.replace(old, repr(str(runtime)) + ', str(EVAL_ROOT / "driver.lua"),'))
    if boundary:
        driver = support / "driver.lua"
        body = driver.read_text()
        anchor = "session:add_user(prompt)\n"
        assert body.count(anchor) == 1
        body = body.replace(anchor, anchor + '''
local boundary_seed
if os.getenv("LCA_RECOVERY_BOUNDARY") == "snake_wave" then
    boundary_seed = dofile(options.root .. "/evals/recovery_boundary.lua").seed(session)
    write_file(assert(options.output:match("^(.*)/[^/]+$")) .. "/boundary.json", json.encode(boundary_seed))
end
''')
        anchor = "local tool_calls = 0\n"
        assert body.count(anchor) == 1
        body = body.replace(anchor, '''if boundary_seed then
    local all = {}
    for _, event in ipairs(boundary_seed.events) do all[#all+1] = event end
    for _, event in ipairs(result.events or {}) do all[#all+1] = event end
    result.events = all
    elapsed_ms = elapsed_ms + boundary_seed.elapsed_ms
end
''' + anchor)
        if inspected:
            body = body.replace('.seed(session)', '.seed(session, {inspected=true})')
        if validation:
            body = body.replace('if os.getenv("LCA_RECOVERY_BOUNDARY") == "snake_wave" then',
                                'if os.getenv("LCA_RECOVERY_BOUNDARY") == "receipt_insert" or os.getenv("LCA_RECOVERY_BOUNDARY") == "receipt_delete" then')
            body = body.replace('dofile(options.root .. "/evals/recovery_boundary.lua").seed(session, {inspected=true})',
                                'dofile(options.root .. "/evals/fresh_recovery_boundary.lua").seed(session, json.decode(read_file(options.root .. "/evals/fresh_recovery_fixtures.json"))[os.getenv("LCA_RECOVERY_BOUNDARY")])')
        driver.write_text(body)
    shutil.copy2(root / "evals/verification_evidence.py", out)
    shutil.copy2(root / "evals/fresh_recovery_grader.py", out)
    shutil.copy2(__file__, out / "screen.py")
    theory = "astra_snapshot_inspected_boundary_screen" if inspected else ("astra_snapshot_boundary_screen" if boundary else THEORY)
    if validation:
        theory = "astra_snapshot_fresh_validation"
    shutil.copy2(root / "evals/theories" / (theory + ".json"), out / "theory.json")
    scenarios = ["simple_prompt", "snake_recovery_boundary" if boundary else "import_shift_edit"]
    if validation:
        scenarios = ["simple_prompt", "receipt_insert", "receipt_delete"]
    for scenario in scenarios:
        shutil.copytree(root / "evals/scenarios" / scenario, out / "scenarios" / scenario,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for arm in ("baseline", "snapshot"):
        shutil.copytree(root / "lua", out / arm / "lua")
        (out / arm / "evals").mkdir()
        for source in support.iterdir():
            if source.suffix in (".lua", ".json"):
                shutil.copy2(source, out / arm / "evals" / source.name)
    edit = out / "snapshot/lua/agent/tools/edit.lua"
    body = edit.read_text()
    assert body.count("\nreturn edit\n") == 1
    edit.write_text(body.replace("\nreturn edit\n", '\nreturn require("agent.tools.edit_snapshot_recovery").install(edit)\n'))
    shutil.copy2(root / "evals/edit_snapshot_recovery.lua", out / "snapshot/lua/agent/tools/edit_snapshot_recovery.lua")
    arms = ["baseline", "snapshot"]
    seed = 929 if validation else (928 if inspected else (927 if boundary else 926))
    rng = random.Random(seed)
    rng.shuffle(arms)
    coding = scenarios[1:]
    if validation:
        rng.shuffle(coding)
    cells = [["simple_prompt", "baseline"], ["simple_prompt", "snapshot"]]
    for scenario in coding:
        if validation:
            arms = ["baseline", "snapshot"]
            rng.shuffle(arms)
        cells.extend([[scenario, arm] for arm in arms])
    m = dict(study_kind="screen", decision_scope="screen_only", seed=seed, theory_id=theory,
             boundary=boundary, inspected=inspected, validation=validation,
             model="gpt-6-astra", reasoning="high", max_runs=len(cells), max_seconds=360,
             max_estimated_cost_usd=1.50,
             lua_runtime=str(runtime), lua_runtime_sha256=sha(runtime),
             lua_environment={key: os.environ[key] for key in ("LUA_PATH", "LUA_CPATH")},
             cells=cells,
             engine_revision=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
             hashes={arm: run.tree_digest(out / arm) for arm in ("baseline", "snapshot")},
             fixture_hashes={name: run.tree_digest(out / "scenarios" / name) for name in scenarios},
             support_sha256=run.tree_digest(support), runner_sha256=sha(out / "screen.py"),
             shared_grader_hashes={name: sha(out / name) for name in ("verification_evidence.py", "fresh_recovery_grader.py")},
             theory_sha256=sha(out / "theory.json"))
    (out / "checkout.diff").write_bytes(subprocess.check_output(["git", "diff", "--binary"], cwd=root))
    save(out / "manifest.json", m)
    print(json.dumps(m, indent=2))


def execute(out):
    sys.path.insert(0, str(out / "support"))
    import run
    m = json.loads((out / "manifest.json").read_text())
    assert sha(Path(__file__)) == m["runner_sha256"]
    assert sha(out / "theory.json") == m["theory_sha256"]
    assert sha(Path(m["lua_runtime"])) == m["lua_runtime_sha256"]
    os.environ.update(m["lua_environment"])
    with (out / "started.json").open("x") as f:
        json.dump({"started": time.time()}, f)
    run.EVAL_ROOT = out / "support"
    results, spent, active_seconds = [], 0.0, 0.0
    contracts = {}
    boundary_prefix = {}
    try:
        for index, (scenario, arm) in enumerate(m["cells"], 1):
            assert run.tree_digest(out / arm) == m["hashes"][arm]
            assert run.tree_digest(out / "scenarios" / scenario) == m["fixture_hashes"][scenario]
            for name, expected in m.get("shared_grader_hashes", {}).items():
                assert sha(out / name) == expected, "shared grader drift"
            # Imports generate only bytecode; it is not part of frozen support.
            shutil.rmtree(out / "support/__pycache__", ignore_errors=True)
            assert run.tree_digest(out / "support") == m["support_sha256"]
            remaining = m["max_seconds"] - active_seconds
            assert remaining >= 1 and spent < m["max_estimated_cost_usd"], "budget exhausted"
            directory = out / f"cell-{index:02d}-{scenario}-{arm}"
            config = json.loads((out / "scenarios" / scenario / "scenario.json").read_text())
            if scenario == "simple_prompt":
                config["environment"] = {"unset": ["LCA_RECOVERY_BOUNDARY"]}
            config["timeout_seconds"] = min(150, int(remaining))
            args = argparse.Namespace(model=m["model"], reasoning=m["reasoning"],
                                      credentials="~/.lca-credentials.json", seed=m["seed"],
                                      result_dir=str(directory), keep=True, judge="none", judge_model=None)
            run.PROJECT_ROOT = out / arm
            variant = dict(id=arm, model=m["model"], reasoning=m["reasoning"], context_mode="normal")
            print(f"Running {index}/{m['max_runs']}: {scenario}/{arm}", flush=True)
            started = time.monotonic()
            result = run.run_once(out / "scenarios" / scenario, config, args, 1, variant, m.get("theory_id", THEORY))
            active_seconds += time.monotonic() - started
            results.append(result)
            save(out / "screen-results.json", results)
            metrics = result["metrics"]
            cost = metrics.get("estimated_api_cost_usd")
            if cost is not None:
                spent += cost
            save(out / "accounting.json", dict(known_estimated_cost=spent, active_seconds=active_seconds))
            assert cost is not None and not metrics.get("usage_unavailable_calls"), "unknown usage"
            assert result["passed"], "artifact/evidence failure"
            trajectory = json.loads((directory / "trajectory.json").read_text())
            assert not trajectory.get("error") and not trajectory["context_pilot"]["errors"]
            requests = sorted(directory.glob("request-*.json"))
            assert requests
            for file in requests:
                request = json.loads(file.read_text())
                assert request["model"] == m["model"] and request["reasoning_effort"] == m["reasoning"]
            payloads = sorted(directory.glob("provider-request-*.json"))
            assert payloads
            for file in payloads:
                payload = json.loads(file.read_text())
                assert payload["model"] == m["model"] and payload["reasoning"]["effort"] == m["reasoning"]
                contract = {key: payload.get(key) for key in ("instructions", "tools", "reasoning", "model", "service_tier")}
                normalized = re.sub(r"/tmp/lca-eval-[^/\s\"\\]+/workspace", "<WORKSPACE>", json.dumps(contract, sort_keys=True))
                if scenario in contracts:
                    assert normalized == contracts[scenario], "prompt/tool contract changed"
                else:
                    contracts[scenario] = normalized
            recoveries = sum(bool((e.get("result") or {}).get("snapshot_recovery"))
                             for e in trajectory.get("events", []))
            assert arm == "snapshot" or recoveries == 0
            if scenario in {"snake_recovery_boundary", "receipt_insert", "receipt_delete"}:
                boundary = json.loads((directory / "boundary.json").read_text())
                final = boundary["body_result"]
                assert bool(final.get("snapshot_recovery")) == (arm == "snapshot")
                assert final["is_error"] == (arm == "baseline")
                # Identical native history through the final call; only its result differs.
                prefix = boundary["messages"][:-1]
                if scenario not in boundary_prefix:
                    boundary_prefix[scenario] = prefix
                else:
                    assert prefix == boundary_prefix[scenario], "seeded native history differs"
                first = json.loads(requests[0].read_text())
                assert first["messages"] == boundary["messages"], "outgoing request lost seeded history"
                if scenario == "snake_recovery_boundary":
                    body = next(e for e in boundary["events"] if e["name"] == "read" and e["args"]["path"] == "snake.py")["result"]["content"]
                    assert "62:JPJA:" in body and "124:lNQO:" in body
                else:
                    spec = json.loads((out / "support/fresh_recovery_fixtures.json").read_text())[scenario]
                    args = boundary["events"][-1]["args"]
                    assert args["path"] == spec["path"] and args["content"] == spec["new_body"]
                    assert args["start_line"] == spec["original_start"] + spec["delta"]
                    assert args["end_line"] == spec["original_end"] + spec["delta"]
                    source = boundary["events"][1]["result"]["content"]
                    for field, old_line in (("start_tag", spec["original_start"]), ("end_tag", spec["original_end"])):
                        assert f"{old_line}:{args[field]}:" in source
                if m.get("inspected"):
                    assert boundary["events"][0]["args"]["path"] == "README.md"
                    assert len(boundary["events"]) == 5
            result["snapshot_recoveries"] = recoveries
            result["activation_audit_passed"] = True
            save(out / "screen-results.json", results)
            print(json.dumps(dict(passed=True, recoveries=recoveries, metrics=metrics)), flush=True)
        for arm in ("baseline", "snapshot"):
            assert run.tree_digest(out / arm) == m["hashes"][arm]
        save(out / "complete.json", dict(known_estimated_cost=spent, active_seconds=active_seconds,
                                        decision_scope="screen_only", prompt_tool_parity=True))
    except BaseException as exc:
        save(out / "stop.json", dict(reason=str(exc), known_estimated_cost=spent,
                                    active_seconds=active_seconds, completed_cells=len(results)))
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["plan", "plan-boundary", "plan-inspected-boundary", "plan-validation", "run"])
    parser.add_argument("directory", type=Path)
    options = parser.parse_args()
    if options.mode == "run":
        execute(options.directory.resolve())
    else:
        plan(options.directory.resolve(), boundary=options.mode != "plan", inspected=options.mode in {"plan-inspected-boundary", "plan-validation"}, validation=options.mode == "plan-validation")
