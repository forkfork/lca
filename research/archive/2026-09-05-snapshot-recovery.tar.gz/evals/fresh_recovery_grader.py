"""Independent artifact grading for the two final recovery fixtures."""
import ast
import json
import subprocess
import sys
from pathlib import Path
from verification_evidence import verified_after_mutations


def grade(scenario, workspace, trajectory):
    contract = json.loads((scenario / "contract.json").read_text())
    def files(root):
        return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*")
                if p.is_file() and "__pycache__" not in p.parts}
    before, after = files(scenario / "fixture"), files(workspace)
    target = contract["path"]
    scope = before.keys() == after.keys() and all(after[name] == body for name, body in before.items() if name != target)
    unrelated = removed = False
    try:
        old, new = ast.parse(before[target]), ast.parse(after.get(target, b""))
        def keep(node):
            if isinstance(node, ast.FunctionDef) and node.name == contract["target"]:
                return False
            if isinstance(node, ast.ImportFrom) and node.module in contract["allowed_imports"]:
                return False
            if isinstance(node, ast.Assign) and all(isinstance(t, ast.Name) and t.id in contract["removed_names"] for t in node.targets):
                return False
            return True
        unrelated = [ast.dump(n) for n in old.body if keep(n)] == [ast.dump(n) for n in new.body if keep(n)]
        names = {n.id for n in ast.walk(new) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)}
        removed = not names.intersection(contract["removed_names"])
    except (SyntaxError, ValueError):
        pass
    public = subprocess.run([sys.executable, "-m", "unittest", "-v"], cwd=workspace, text=True, capture_output=True, timeout=15)
    hidden = subprocess.run([sys.executable, "-c", contract["hidden"]], cwd=workspace, text=True, capture_output=True, timeout=15)
    gates = dict(public_tests=public.returncode == 0, hidden_behavior=hidden.returncode == 0,
                 protected_scope=scope, unrelated_code=unrelated, obsolete_names_removed=removed,
                 verification=verified_after_mutations(trajectory.get("events", [])))
    return dict(passed=all(gates.values()), score=100*sum(gates.values())/len(gates), hard_gates=gates,
                evidence=dict(public_output=public.stdout+public.stderr, hidden_output=hidden.stdout+hidden.stderr))
