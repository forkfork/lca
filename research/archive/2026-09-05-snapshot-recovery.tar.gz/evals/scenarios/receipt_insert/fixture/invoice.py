import itertools


CURRENCY = "USD"
TAX_CODES = ("standard", "exempt")


def next_invoice_ids(start):
    return itertools.count(start)


def currency():
    return CURRENCY


def tax_codes():
    return TAX_CODES


def billable_cents(amount):
    return int(amount * 100)


def invoice_label(number):
    return f"INV-{number:06d}"
