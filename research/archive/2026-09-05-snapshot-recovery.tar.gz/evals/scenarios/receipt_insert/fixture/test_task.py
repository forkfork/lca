import unittest
import invoice

class InvoiceTests(unittest.TestCase):
    def test_rounding(self):
        for value, expected in [(0,0),(1.005,101),(2.675,268),(10.004,1000)]:
            self.assertEqual(invoice.billable_cents(value), expected)
    def test_negative(self):
        with self.assertRaises(ValueError): invoice.billable_cents(-0.001)
    def test_preserved(self):
        self.assertEqual(invoice.invoice_label(3), "INV-000003")
        self.assertEqual(invoice.currency(), "USD")
