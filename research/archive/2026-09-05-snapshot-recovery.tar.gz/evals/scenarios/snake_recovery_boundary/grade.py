import ast
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from verification_evidence import verified_after_mutations


def grade(workspace, trajectory):
    fixture = Path(__file__).with_name("fixture")
    def files(root):
        return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*")
                if p.is_file() and "__pycache__" not in p.parts}
    original, actual = files(fixture), files(workspace)
    scope = (actual.keys() == original.keys() and all(
        actual[name] == body for name, body in original.items() if name != "snake.py"))
    preserved = False
    try:
        old = ast.parse(original["snake.py"])
        new = ast.parse(actual.get("snake.py", b""))
        def unrelated(tree):
            return [ast.dump(node) for node in tree.body
                    if not (isinstance(node, ast.FunctionDef) and node.name == "wave_offset")
                    and not (isinstance(node, ast.Import) and all(a.name == "math" for a in node.names))]
        preserved = unrelated(old) == unrelated(new)
    except (SyntaxError, ValueError):
        pass
    public = subprocess.run([sys.executable, "-m", "unittest", "-v"], cwd=workspace,
                            text=True, capture_output=True, timeout=15)
    hidden = subprocess.run([sys.executable, "-c", 'import math, snake\nfor phase in [-100,-2.3,-0.1,0.2,1.1,2.8,10,100]:\n    assert snake.wave_offset(phase) == round(3*math.sin(phase))\nassert snake.WIDTH == 32 and snake.HEIGHT == 16\nassert snake.Game().score == 0\n'], cwd=workspace, text=True, capture_output=True, timeout=15)
    gates = dict(public_tests=public.returncode == 0, hidden_behavior=hidden.returncode == 0,
                 protected_scope=scope, unrelated_code=preserved,
                 verification=verified_after_mutations(trajectory.get("events", [])))
    return dict(passed=all(gates.values()), score=sum(gates.values()) * 20, hard_gates=gates,
                evidence=dict(public_output=public.stdout + public.stderr,
                              hidden_output=hidden.stdout + hidden.stderr))


if __name__ == "__main__":
    print(json.dumps(grade(Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text()))))
