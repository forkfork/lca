import math
import unittest
import snake

class WaveTests(unittest.TestCase):
    def test_wave(self):
        for phase in [0, math.pi/2, math.pi, 3*math.pi/2, -math.pi/2]:
            self.assertEqual(snake.wave_offset(phase), round(3*math.sin(phase)))
    def test_game_still_exists(self):
        game = snake.Game()
        self.assertEqual(game.score, 0)
        self.assertTrue(game.snake)
