#!/usr/bin/env python3
"""ASCII Snake for a terminal. Run with: python3 snake.py"""

import curses
import random
import time
from collections import deque


WIDTH, HEIGHT = 32, 16
DIRECTIONS = {
    curses.KEY_UP: (0, -1), ord("w"): (0, -1),
    curses.KEY_DOWN: (0, 1), ord("s"): (0, 1),
    curses.KEY_LEFT: (-1, 0), ord("a"): (-1, 0),
    curses.KEY_RIGHT: (1, 0), ord("d"): (1, 0),
}


class Game:
    def __init__(self, width=WIDTH, height=HEIGHT):
        if width < 4 or height < 2:
            raise ValueError("Board must be at least 4 by 2")
        self.width, self.height = width, height
        x, y = width // 2, height // 2
        self.snake = deque([(x, y), (x - 1, y), (x - 2, y)])
        self.direction = (1, 0)
        self.score = 0
        self.over = False
        self.won = False
        self.food = self.spawn_food()

    def spawn_food(self):
        occupied = set(self.snake)
        free = [(x, y) for y in range(self.height)
                for x in range(self.width) if (x, y) not in occupied]
        return random.choice(free) if free else None

    def step(self, direction=None):
        if self.over:
            return
        if direction is not None and direction != tuple(-v for v in self.direction):
            self.direction = direction
        dx, dy = self.direction
        x, y = self.snake[0]
        head = (x + dx, y + dy)
        eating = head == self.food
        # The tail vacates its cell on non-growing moves.
        body = list(self.snake) if eating else list(self.snake)[:-1]
        if not (0 <= head[0] < self.width and 0 <= head[1] < self.height) or head in body:
            self.over = True
            return
        self.snake.appendleft(head)
        if eating:
            self.score += 1
            self.food = self.spawn_food()
            if self.food is None:
                self.won = self.over = True
        else:
            self.snake.pop()


def draw(screen, game, paused):
    screen.erase()
    rows, cols = screen.getmaxyx()
    if rows < HEIGHT + 7 or cols < WIDTH + 2:
        message = f"Resize to {WIDTH + 2}x{HEIGHT + 7}; Q quits"
        screen.addnstr(0, 0, message, max(0, cols - 1))
        screen.refresh()
        return False
    screen.addstr(0, 0, f"ASCII SNAKE   Score: {game.score}")
    screen.addstr(2, 0, "+" + "-" * WIDTH + "+")
    for y in range(HEIGHT):
        screen.addstr(y + 3, 0, "|" + " " * WIDTH + "|")
    screen.addstr(HEIGHT + 3, 0, "+" + "-" * WIDTH + "+")
    if game.food is not None:
        x, y = game.food
        screen.addch(y + 3, x + 1, "*")
    for index, (x, y) in enumerate(game.snake):
        screen.addch(y + 3, x + 1, "@" if index == 0 else "o")
    screen.addstr(HEIGHT + 4, 0, "Arrows/WASD  Space: pause  Q: quit")
    status = "PAUSED" if paused else "Eat * and avoid walls and yourself"
    if game.over:
        status = "YOU WIN! R: restart" if game.won else "GAME OVER! R: restart"
    screen.addstr(HEIGHT + 5, 0, status)
    screen.refresh()
    return True


def play(screen):
    try:
        curses.curs_set(0)
    except curses.error:
        pass
    screen.keypad(True)
    screen.timeout(25)
    game = Game()
    paused = False
    pending = None
    next_tick = time.monotonic() + 0.15
    while True:
        fits = draw(screen, game, paused)
        key = screen.getch()
        if 0 <= key < 256:
            key = ord(chr(key).lower())
        if key == ord("q"):
            return
        if key == ord("r") and game.over:
            game = Game()
            paused, pending = False, None
            next_tick = time.monotonic() + 0.15
        elif key == ord(" ") and not game.over:
            paused = not paused
            pending = None
        elif key in DIRECTIONS and pending is None and not paused and fits:
            candidate = DIRECTIONS[key]
            if candidate != tuple(-v for v in game.direction) and candidate != game.direction:
                pending = candidate
        now = time.monotonic()
        if paused or not fits or game.over:
            next_tick = now + 0.15
        elif now >= next_tick:
            game.step(pending)
            pending = None
            next_tick = now + max(0.055, 0.15 - game.score * 0.004)


if __name__ == "__main__":
    try:
        curses.wrapper(play)
    except KeyboardInterrupt:
        pass
    except curses.error as exc:
        raise SystemExit(f"Run Snake in an interactive terminal: {exc}")
