import ast
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from verification_evidence import verified_after_mutations


def grade(workspace, trajectory):
    fixture = Path(__file__).with_name("fixture")
    def files(root):
        return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*")
                if p.is_file() and "__pycache__" not in p.parts}
    original, actual = files(fixture), files(workspace)
    scope = (actual.keys() == original.keys() and all(
        actual[name] == body for name, body in original.items() if name != "pricing.py"))
    preserved = False
    try:
        old = ast.parse(original["pricing.py"])
        new = ast.parse(actual.get("pricing.py", b""))
        def unrelated(tree):
            return [ast.dump(node) for node in tree.body
                    if not (isinstance(node, ast.FunctionDef) and node.name == "package_count")
                    and not (isinstance(node, ast.Import) and all(a.name == "math" for a in node.names))]
        preserved = unrelated(old) == unrelated(new)
    except (SyntaxError, ValueError):
        pass
    public = subprocess.run([sys.executable, "-m", "unittest", "-v"], cwd=workspace,
                            text=True, capture_output=True, timeout=15)
    hidden = subprocess.run([sys.executable, "-c", '''import pricing
for weight, expected in [(0.001,1),(9.999,1),(20,2),(20.001,3),(999,100)]:
    assert pricing.package_count(weight) == expected
for weight in [-0.001,-100]:
    try: pricing.package_count(weight)
    except ValueError: pass
    else: raise AssertionError("negative accepted")
assert pricing.base_fee() == 7
assert 100000 <= pricing.reference_number() < 1000000
'''], cwd=workspace, text=True, capture_output=True, timeout=15)
    gates = dict(public_tests=public.returncode == 0, hidden_behavior=hidden.returncode == 0,
                 protected_scope=scope, unrelated_code=preserved,
                 verification=verified_after_mutations(trajectory.get("events", [])))
    return dict(passed=all(gates.values()), score=sum(gates.values()) * 20, hard_gates=gates,
                evidence=dict(public_output=public.stdout + public.stderr,
                              hidden_output=hidden.stdout + hidden.stderr))


if __name__ == "__main__":
    print(json.dumps(grade(Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text()))))
