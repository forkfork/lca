import random


CURRENCY = "AUD"
BASE_FEE = 7


def reference_number():
    return random.randrange(100000, 1000000)


def currency():
    return CURRENCY


def base_fee():
    return BASE_FEE


def insurance_fee(value):
    return max(0, value) * 0.02


def package_count(weight_kg):
    """Return packages needed when each holds ten kilograms."""
    return round(weight_kg / 10)


def shipping_fee(weight_kg):
    return BASE_FEE + 3 * package_count(weight_kg)
