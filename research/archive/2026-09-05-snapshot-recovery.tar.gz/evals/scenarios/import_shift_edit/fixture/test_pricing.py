import unittest
import pricing

class PricingTests(unittest.TestCase):
    def test_rounding(self):
        for weight, expected in [(0,0),(1,1),(10,1),(10.1,2),(25,3)]:
            self.assertEqual(pricing.package_count(weight), expected)
    def test_negative(self):
        with self.assertRaises(ValueError): pricing.package_count(-1)
    def test_preserved(self):
        self.assertEqual(pricing.currency(), "AUD")
        self.assertEqual(pricing.insurance_fee(100), 2)
        self.assertEqual(pricing.shipping_fee(10.1), 13)
