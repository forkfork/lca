"""Small display-label utilities."""

LEGACY_PREFIX = "old"
LEGACY_SEPARATOR = "::"

MAX_LABEL_LENGTH = 120


def raw_join(parts):
    return "::".join(parts)


def max_label_length():
    return MAX_LABEL_LENGTH


def format_label(parts):
    return "/".join(parts)


def truncate_label(value):
    return value[:MAX_LABEL_LENGTH]
