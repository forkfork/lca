import unittest
import labels

class LabelTests(unittest.TestCase):
    def test_normalization(self):
        self.assertEqual(labels.format_label([" Team ", "", " ALPHA"]), "team / alpha")
        self.assertEqual(labels.format_label([" ", ""]), "")
        self.assertEqual(labels.format_label(["Straße"]), "strasse")
    def test_removed(self):
        self.assertFalse(hasattr(labels, "LEGACY_PREFIX"))
        self.assertFalse(hasattr(labels, "LEGACY_SEPARATOR"))
    def test_preserved(self):
        self.assertEqual(labels.raw_join([" A ","B"]), " A ::B")
        self.assertEqual(labels.max_label_length(), 120)
