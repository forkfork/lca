import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from fresh_recovery_grader import grade
print(json.dumps(grade(Path(__file__).resolve().parent, Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text()))))
