-- Reconstruct a known mixed-coordinate/tag failure before a live continuation.
-- The calls are fixture history, not newly sampled model output.
local json = require("agent.util.json")
local fs = require("agent.util.fs")
local read = require("agent.tools.read")
local registry = require("agent.tool_registry")
local protocol = require("agent.tool_protocol")
local uv = require("luv")
local M = {}

local function arguments_json(args)
	local keys, parts = {}, {}
	for key in pairs(args) do keys[#keys+1] = key end
	table.sort(keys)
	for _, key in ipairs(keys) do parts[#parts+1] = json.encode(key) .. ":" .. json.encode(args[key]) end
	return "{" .. table.concat(parts, ",") .. "}"
end

function M.seed(session, options)
	local started = uv.hrtime()
	local original = fs.read_file(session.cwd .. "/snake.py")
	local lines = read.split_lines(original)
	assert(read.line_tag(5, lines[5]) == "GxrL", "unexpected import fixture")
	assert(read.line_tag(62, lines[62]) == "JPJA" and read.line_tag(124, lines[124]) == "lNQO",
		"unexpected captured body coordinates/tags")
	local replacement = "def wave_offset(phase):\n    return round(3 * math.sin(phase))\n\n\n"
		.. table.concat(lines, "\n", 62, 124)
	local calls = {
		{name="read",args={path="snake.py",limit=200}},
		{name="read",args={path="test_wave.py",limit=200}},
		{name="edit",args={path="snake.py",start_line=5,end_line=5,start_tag="GxrL",end_tag="GxrL",
			content="import math\nimport random"}},
		{name="edit",args={path="snake.py",start_line=63,end_line=125,start_tag="JPJA",end_tag="lNQO",
			content=replacement}},
	}
	if options and options.inspected then
		table.insert(calls, 1, {name="read",args={path="README.md",limit=200}})
	end
	local events = {}
	for index, call in ipairs(calls) do
		local id = "call_boundary_" .. index
		session:add_assistant("", {{type="function_call",call_id=id,name=call.name,
			arguments=arguments_json(call.args),status="completed"}})
		local result = registry.execute(call.name, call.args, {cwd=session.cwd,session=session})
		if index < #calls then assert(not result.is_error, result.content) end
		session:add_tool_result(call.name, protocol.tool_result_message(call.name,result,call.args),id)
		events[#events+1] = {name=call.name,args=call.args,result=result,fixture_seed=true}
	end
	local last = events[#events].result
	assert((last.is_error and last.summary == "stale tag") or last.snapshot_recovery,
		"boundary did not activate as registered")
	return {kind="reconstructed_boundary",events=events,messages=session.messages,
		elapsed_ms=(uv.hrtime()-started)/1e6,
		body_result=last, note="Literal captured coordinates/tags; reconstructed wave helper body, not the truncated original visual-feature payload"}
end

return M
