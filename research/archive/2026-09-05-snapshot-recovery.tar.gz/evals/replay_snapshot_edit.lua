-- Replay the captured Snake coordinates/tags with an inert replacement marker.
local root, source = assert(arg[1]), assert(arg[2])
package.path = root .. "/lua/?.lua;" .. package.path
require("luarocks.loader")
local fs = require("agent.util.fs")
local read = require("agent.tools.read")
local edit = require("agent.tools.edit")
local prototype = dofile(root .. "/evals/edit_snapshot_recovery.lua")
local json = require("agent.util.json")
local uv = require("luv")
local original = fs.read_file(source)
local lines = read.split_lines(original)
assert(read.line_tag(5, lines[5]) == "GxrL")
assert(read.line_tag(62, lines[62]) == "JPJA")
assert(read.line_tag(124, lines[124]) == "lNQO")
local dir = assert(uv.fs_mkdtemp("/tmp/lca-snapshot-replay-XXXXXX"))
local target = dir .. "/snake.py"
local outcomes = {}
for _, arm in ipairs({"baseline", "snapshot"}) do
	fs.write_file(target, original)
	local tool = arm == "snapshot" and prototype.install({ execute = edit.execute }) or edit
	local context = {cwd=dir,session={}}
	local import = {path=target,start_line=5,end_line=5,start_tag="GxrL",end_tag="GxrL",content="import math\nimport random"}
	assert(not tool.execute(import, context).is_error)
	local shifted = fs.read_file(target)
	local args = {path=target,start_line=63,end_line=125,start_tag="JPJA",end_tag="lNQO",
		content="# snapshot replay marker\n" .. table.concat(lines,"\n",62,124)}
	local result = tool.execute(args, context)
	local expected = shifted:gsub("def draw%(screen, game, paused%):", "# snapshot replay marker\ndef draw(screen, game, paused):", 1)
	if arm == "baseline" then
		assert(result.is_error and result.summary=="stale tag")
		assert(fs.read_file(target)==shifted)
	else
		assert(not result.is_error and result.snapshot_recovery)
		assert(fs.read_file(target)==expected)
	end
	outcomes[arm] = {is_error=result.is_error,summary=result.summary,exact_bytes_passed=true,
		snapshot_recovery=result.snapshot_recovery}
end
os.remove(target);assert(uv.fs_rmdir(dir))
print(json.encode({probe="Captured import and mixed coordinate/tag arguments; inert replacement instead of truncated original generated body",outcomes=outcomes}))
