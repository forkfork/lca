local root = arg[0]:match("^(.*)/tests/") or "."
package.path = root .. "/lua/?.lua;" .. package.path
require("luarocks.loader")
local uv = require("luv")
local fs = require("agent.util.fs")
local json = require("agent.util.json")
local registry = require("agent.tool_registry")
local sessions = require("agent.session")
local seed = dofile(root .. "/evals/recovery_boundary.lua")
local prototype = dofile(root .. "/evals/edit_snapshot_recovery.lua")
local fixture = root .. "/evals/scenarios/snake_recovery_boundary/fixture"
local dir = assert(uv.fs_mkdtemp("/tmp/lca-boundary-test-XXXXXX"))
local baseline_prefix = {}
for _, arm in ipairs({"baseline", "snapshot"}) do
  if arm == "snapshot" then prototype.install(registry.get("edit")) end
  for _, inspected in ipairs({false,true}) do
	for _, name in ipairs({"snake.py", "test_wave.py", "README.md"}) do
		fs.write_file(dir .. "/" .. name, fs.read_file(fixture .. "/" .. name))
	end
	local session = sessions.create({cwd=dir,model="gpt-6-astra",reasoning_effort="high"})
	session.cwd = dir
	session:add_user("Add wave_offset and verify it.")
	local boundary = seed.seed(session, {inspected=inspected})
	local pair_count = inspected and 5 or 4
	assert(#boundary.events == pair_count and #boundary.messages == 1 + pair_count*2)
	assert(boundary.body_result.is_error == (arm == "baseline"))
	assert((boundary.body_result.snapshot_recovery ~= nil) == (arm == "snapshot"))
	local prefix = {}
	for i=1,pair_count*2 do prefix[i]=boundary.messages[i] end
	if arm == "baseline" then baseline_prefix[pair_count]=prefix else
		for i=1,pair_count*2 do
			assert(prefix[i].role == baseline_prefix[pair_count][i].role)
			assert(prefix[i].text == baseline_prefix[pair_count][i].text)
			assert(prefix[i].native_call_id == baseline_prefix[pair_count][i].native_call_id)
			local a,b=prefix[i].provider_items,baseline_prefix[pair_count][i].provider_items
			if a then
				assert(a[1].call_id == b[1].call_id and a[1].name == b[1].name)
				-- JSON member order is not guaranteed; compare argument values.
				local aa,bb=json.decode(a[1].arguments),json.decode(b[1].arguments)
				for key,value in pairs(aa) do assert(value == bb[key]) end
			end
		end
	end
	local calls={}
	for _, message in ipairs(boundary.messages) do
		for _, item in ipairs(message.provider_items or {}) do calls[item.call_id]=true end
		if message.native_call_id then assert(calls[message.native_call_id]);calls[message.native_call_id]=nil end
	end
	assert(next(calls)==nil, "unclosed native call/result pair")
	local payload=json.decode(require("agent.providers.codex")._request_body({
		model="gpt-6-astra",reasoning_effort="high",system_prompt="Boundary protocol preflight",
		messages=session.messages,native_tool_calling=true,native_tool_pair_closure=true,
	}))
	local wire_calls,wire_outputs={},0
	for _,item in ipairs(payload.input) do
		if item.type=="function_call" then wire_calls[item.call_id]=true end
		if item.type=="function_call_output" then
			assert(wire_calls[item.call_id],"wire output lost native call")
			wire_calls[item.call_id]=nil;wire_outputs=wire_outputs+1
		end
	end
	assert(wire_outputs==pair_count and next(wire_calls)==nil,"provider lost seeded native pairs")
	local body=fs.read_file(dir .. "/snake.py")
	local expected=fs.read_file(fixture .. "/snake.py"):gsub("import random", "import math\nimport random",1)
	if arm=="snapshot" then
		expected=expected:gsub("def draw%(screen, game, paused%):",
			"def wave_offset(phase):\n    return round(3 * math.sin(phase))\n\n\ndef draw(screen, game, paused):",1)
	end
	assert(body==expected, "unexpected boundary file bytes")
	print("PASS "..arm.." inspected="..tostring(inspected).." boundary activation, native pairing and exact file bytes")
  end
end
os.remove(dir .. "/snake.py");os.remove(dir .. "/test_wave.py");os.remove(dir .. "/README.md");assert(uv.fs_rmdir(dir))
