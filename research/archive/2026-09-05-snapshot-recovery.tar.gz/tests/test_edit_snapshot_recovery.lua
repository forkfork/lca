local root = (arg[0]:match("^(.*)/tests/") or ".")
package.path = root .. "/lua/?.lua;" .. package.path
local read = require("agent.tools.read")
local original = require("agent.tools.edit")
local prototype = dofile(root .. "/evals/edit_snapshot_recovery.lua")
local tool = prototype.install({ execute = original.execute })
local uv = require("luv")
local dir = assert(uv.fs_mkdtemp("/tmp/lca-snapshot-tests-XXXXXX"))
local target = dir .. "/sample.txt"
local function write(body) local f=assert(io.open(target,"wb")); f:write(body); f:close() end
local function contents() local f=assert(io.open(target,"rb")); local s=f:read("*a"); f:close(); return s end
local function args(body, first, last, replacement)
	local lines=read.split_lines(body)
	return {path=target,start_line=first,end_line=last,start_tag=read.line_tag(first,lines[first]),
		end_tag=read.line_tag(last,lines[last]),content=replacement}
end
local passed=0
local function test(name, f)
	local ok,err=pcall(f)
	if not ok then io.stderr:write(name,": ",tostring(err),"\n"); os.exit(1) end
	passed=passed+1; print("PASS "..name)
end
local before="import random\nheader\nunique start\nold middle\nunique end\ntail\n"
local function setup(executor, body)
	body=body or before; write(body)
	local context={cwd=dir,session={}}
	assert(not executor.execute(args(body,1,1,"import math\nimport random"),context).is_error)
	local edit=args(body,3,5,"replacement")
	edit.start_line=4; edit.end_line=6
	return context,edit
end
test("baseline reproduces updated coordinates with old tags",function()
	local context,edit=setup(original);local expected=contents()
	assert(original.execute(edit,context).is_error);assert(contents()==expected)
end)
test("recovers entire unchanged range and preserves exact surrounding bytes",function()
	local context,edit=setup(tool)
	local result=tool.execute(edit,context)
	assert(not result.is_error and result.snapshot_recovery)
	assert(contents()=="import math\nimport random\nheader\nreplacement\ntail\n")
end)
test("external interior changes reject without writing",function()
	local context,edit=setup(tool);write(contents():gsub("old middle","operator change"));local expected=contents()
	assert(tool.execute(edit,context).is_error);assert(contents()==expected)
end)
test("external changes outside range also reject",function()
	local context,edit=setup(tool);write(contents().."external\n");local expected=contents()
	assert(tool.execute(edit,context).is_error);assert(contents()==expected)
end)
test("sessions cannot reuse another session receipt",function()
	local _,edit=setup(tool);local expected=contents()
	assert(tool.execute(edit,{cwd=dir,session={}}).is_error);assert(contents()==expected)
end)
test("duplicate range is ambiguous",function()
	local body=before.."unique start\nold middle\nunique end\n"
	local context,edit=setup(tool,body);local expected=contents()
	assert(tool.execute(edit,context).is_error);assert(contents()==expected)
end)
test("own edit changing interior cannot recover old range",function()
	write(before);local context={cwd=dir,session={}}
	assert(not tool.execute(args(before,4,4,"inserted\nchanged"),context).is_error)
	local edit=args(before,3,5,"replacement");edit.start_line=4;edit.end_line=6
	local expected=contents();assert(tool.execute(edit,context).is_error);assert(contents()==expected)
end)
test("oversized snapshots fail closed",function()
	local context,edit=setup(tool,before..string.rep("x",128*1024));local expected=contents()
	assert(tool.execute(edit,context).is_error);assert(contents()==expected)
end)
test("syntax checks still reject corrected edit",function()
	local py=dir.."/sample.py";local oldtarget=target;target=py
	local body="import random\n\ndef answer():\n    return 1\n"
	write(body);local context={cwd=dir,session={}}
	assert(not tool.execute(args(body,1,1,"import math\nimport random"),context).is_error)
	local edit=args(body,3,4,"def broken(:");edit.start_line=4;edit.end_line=5
	local expected=contents();local result=tool.execute(edit,context)
	assert(result.is_error and result.summary=="syntax error — not written");assert(contents()==expected)
	os.remove(target);target=oldtarget
end)
os.remove(target);assert(uv.fs_rmdir(dir));print(passed.." snapshot recovery tests passed")
