local root=arg[0]:match("^(.*)/tests/") or "."
package.path=root.."/lua/?.lua;"..package.path
require("luarocks.loader")
local uv=require("luv")
local fs=require("agent.util.fs")
local json=require("agent.util.json")
local read=require("agent.tools.read")
local registry=require("agent.tool_registry")
local sessions=require("agent.session")
local seed=dofile(root.."/evals/fresh_recovery_boundary.lua")
local specs=json.decode(fs.read_file(root.."/evals/fresh_recovery_fixtures.json"))
local dir=assert(uv.fs_mkdtemp("/tmp/lca-fresh-boundary-XXXXXX"))
local prefixes={}
local function replace(body,first,last,replacement)
	local lines=read.split_lines(body)
	for _=first,last do table.remove(lines,first) end
	local insert=replacement=="" and {} or read.split_lines(replacement)
	for i=#insert,1,-1 do table.insert(lines,first,insert[i]) end
	return table.concat(lines,"\n")
end
local passed=0
for _,arm in ipairs({"baseline","snapshot"}) do
	if arm=="snapshot" then dofile(root.."/evals/edit_snapshot_recovery.lua").install(registry.get("edit")) end
	for _,name in ipairs({"receipt_insert","receipt_delete"}) do
		local spec=specs[name]
		for _,external in ipairs({false,true}) do
			for _,file in ipairs({spec.path,"README.md","test_task.py"}) do
				fs.write_file(dir.."/"..file,fs.read_file(root.."/evals/scenarios/"..name.."/fixture/"..file))
			end
			local original=fs.read_file(dir.."/"..spec.path)
			local session=sessions.create({model="gpt-6-astra",reasoning_effort="high"});session.cwd=dir
			session:add_user("Complete the fixture task and run its tests.")
			local result=seed.seed(session,spec,external)
			local recover=arm=="snapshot" and not external
			assert(result.body_result.is_error==not recover)
			assert((result.body_result.snapshot_recovery~=nil)==recover)
			local expected=replace(original,spec.first_start,spec.first_end,spec.first_content)
			if external then expected=expected.."\n# concurrent operator note\n" end
			if recover then expected=replace(expected,spec.original_start+spec.delta,spec.original_end+spec.delta,spec.new_body) end
			assert(fs.read_file(dir.."/"..spec.path)==expected,"unexpected write: "..name)
			local key=name..tostring(external)
			local prefix={}
			for i=1,#result.messages-1 do prefix[i]=result.messages[i] end
			if arm=="baseline" then prefixes[key]=prefix else
				for i,message in ipairs(prefix) do
					local before=prefixes[key][i]
					assert(message.text==before.text and message.role==before.role and message.native_call_id==before.native_call_id)
					if message.provider_items then
						assert(message.provider_items[1].arguments==before.provider_items[1].arguments)
					end
				end
			end
			local payload=json.decode(require("agent.providers.codex")._request_body({model="gpt-6-astra",
				reasoning_effort="high",system_prompt="offline preflight",messages=session.messages,
				native_tool_calling=true,native_tool_pair_closure=true}))
			local pending,count={},0
			for _,item in ipairs(payload.input) do
				if item.type=="function_call" then pending[item.call_id]=true end
				if item.type=="function_call_output" then
					assert(pending[item.call_id]);pending[item.call_id]=nil;count=count+1
				end
			end
			assert(count==5 and next(pending)==nil)
			passed=passed+1
			print("PASS "..arm.." "..name.." external="..tostring(external).." exact bytes and native pairs")
			for _,file in ipairs({spec.path,"README.md","test_task.py"}) do os.remove(dir.."/"..file) end
		end
	end
end
assert(uv.fs_rmdir(dir));print(passed.." fresh boundary checks passed")
